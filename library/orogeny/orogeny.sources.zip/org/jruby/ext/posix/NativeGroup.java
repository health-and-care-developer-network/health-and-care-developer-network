package org.jruby.ext.posix;

import com.sun.jna.Structure;

public abstract class NativeGroup extends Structure implements Group {
}
