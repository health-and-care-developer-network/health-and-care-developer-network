package org.jruby.ext.posix;

import com.sun.jna.Structure;

public abstract class NativeTimeval extends Structure implements Timeval {
}
