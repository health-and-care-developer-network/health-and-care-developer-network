package org.jruby.ext.posix;

public interface SolarisLibC extends LibC {
}
