package org.jruby.ext.posix;

public interface Timeval {
    public void setTime(long[] timeval);
}
