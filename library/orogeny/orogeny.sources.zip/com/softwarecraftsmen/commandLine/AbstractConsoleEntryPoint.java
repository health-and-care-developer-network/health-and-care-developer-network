/**
 * This file is Copyright © 2009 Vubble Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.commandLine;

import static com.softwarecraftsmen.commandLine.Exit.exitError;
import static com.softwarecraftsmen.commandLine.Exit.exitNormally;
import org.jetbrains.annotations.NotNull;

import static java.lang.Class.forName;
import static java.lang.String.format;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import static java.util.Locale.UK;

public abstract class AbstractConsoleEntryPoint
{
	protected static class NullaryConstructorDelegate<T>
	{
		private final Class<T> aClass;

		@SuppressWarnings({"unchecked"})
		public NullaryConstructorDelegate(final @NotNull Class<? extends T> aClass)
		{
			this.aClass = (Class<T>) aClass;
		}

		@SuppressWarnings({"unchecked"})
		@NotNull
		public T invoke()
		{
			final Constructor<T> nullaryConstructor = findNullaryConstructor();
			try
			{
				return nullaryConstructor.newInstance();
			}
			catch (InstantiationException e)
			{
				throw new IllegalStateException(format(UK, "Could not create an instance of %1$s (Check you BuildScript has a static{configure();} section", aClass.getSimpleName()), e);
			}
			catch (IllegalAccessException e)
			{
				throw new IllegalStateException(format(UK, "Could not create an instance of %1$s because it does not have a nullary constructor", aClass.getSimpleName()), e);
			}
			catch (InvocationTargetException e)
			{
				throw new IllegalStateException(format(UK, "Could not create an instance of %1$s because something went wrong in its constructor", aClass.getSimpleName()), e.getCause());
			}
		}

		@SuppressWarnings({"unchecked"})
		private Constructor<T> findNullaryConstructor()
		{
			final Constructor<?>[] declaredConstructors = aClass.getDeclaredConstructors();
			for (Constructor<?> declaredConstructor : declaredConstructors)
			{
				if (declaredConstructor.getParameterTypes().length == 0)
				{
					final Constructor<T> nullaryConstructor = (Constructor<T>) declaredConstructor;
					nullaryConstructor.setAccessible(true);
					return nullaryConstructor;
				}
			}
			throw new IllegalStateException(format(UK, "Could not create an instance of %1$s because it does not have a nullary constructor", aClass.getSimpleName()));
		}

		@NotNull
		public Class<T> getWrappedClass()
		{
			return aClass;
		}
	}

	private static final ConvenientOptionParser Options = new ConvenientOptionParser();
	protected static NullaryConstructorDelegate<AbstractConsoleEntryPoint> actualConsoleEntryPointConstructor;

	@SuppressWarnings({"unchecked"})
	protected static void help(final @NotNull String message)
	{
		//noinspection ThrowableInstanceNeverThrown
		final StackTraceElement[] stackTraceElements = new RuntimeException().getStackTrace();
		try
		{
			final Class<? extends AbstractConsoleEntryPoint> actualConsoleEntryPointClass = (Class<? extends AbstractConsoleEntryPoint>) forName(stackTraceElements[stackTraceElements.length - 1].getClassName());
			actualConsoleEntryPointConstructor = new NullaryConstructorDelegate<AbstractConsoleEntryPoint>(actualConsoleEntryPointClass);
		}
		catch (ClassNotFoundException e)
		{
			throw new IllegalStateException(e);
		}
		Options.help(message);
	}

	@NotNull
	protected static <T> ConvenientOptionParser.WrappedArgumentAcceptingOptionSpec<T> withRequiredArgument(final @NotNull OptionName<T> optionName, final @NotNull String example)
	{
		return Options.withRequiredArgument(optionName, example);
	}

	@NotNull
	protected static <T> ConvenientOptionParser.WrappedArgumentAcceptingOptionSpec<T> withOptionalArgument(final @NotNull OptionName<T> optionName, final @NotNull String example)
	{
		return Options.withOptionalArgument(optionName, example);
	}

	@NotNull
	protected static ConvenientOptionParser withOptionalBoolean(final @NotNull OptionName<Boolean> optionName, final @NotNull String description)
	{
		Options.withOptionalBoolean(optionName, description);
		return Options;
	}

	@NotNull
	protected static ConvenientOptionSet parseAndExitWithHelpIfRequested(final @NotNull String... arguments)
	{
		return Options.parseAndExitWithHelpIfRequested(arguments);
	}

	protected void exitBadOptions(final @NotNull String template, final @NotNull Object... arguments)
	{
		Options.exitBadOptions(format(UK, template, arguments));
	}

	public static void main(final @NotNull String[] arguments)
	{
		final AbstractConsoleEntryPoint consoleEntryPoint = actualConsoleEntryPointConstructor.invoke();
		final ConvenientOptionSet parsedArguments = parseAndExitWithHelpIfRequested(arguments);
		try
		{
			consoleEntryPoint.entryPoint(parsedArguments);
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			exitError(exception);
		}
		exitNormally();
	}

	protected abstract void entryPoint(final @NotNull ConvenientOptionSet parsedArguments);
}
