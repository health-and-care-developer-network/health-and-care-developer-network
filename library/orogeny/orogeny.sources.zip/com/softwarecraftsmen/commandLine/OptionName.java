/**
 * This file is Copyright © 2009 Vubble Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.commandLine;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class OptionName<T>
{
	@NotNull
	public static <T> OptionName<T> option(final @NotNull String name)
	{
		return new OptionName<T>(name);
	}

	private final String name;

	public OptionName(final @NotNull String name)
	{
		this.name = name;
	}

	@NotNull
	public String toString()
	{
		return format(UK, "%1$s(%2$s)", getClass().getSimpleName(), name);
	}

	public boolean equals(final @Nullable Object o)
	{
		if (this == o)
		{
			return true;
		}
		if (o == null || getClass() != o.getClass())
		{
			return false;
		}

		final OptionName that = (OptionName) o;

		if (!name.equals(that.name))
		{
			return false;
		}

		return true;
	}

	public int hashCode()
	{
		return name.hashCode();
	}

	@NotNull
	public String name()
	{
		return name;
	}
}
