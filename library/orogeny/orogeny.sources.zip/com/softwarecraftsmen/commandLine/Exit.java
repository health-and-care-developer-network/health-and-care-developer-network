/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.commandLine;

import joptsimple.OptionParser;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import static java.lang.System.*;

public final class Exit
{
	private static final int Failure = 1;

	private Exit()
	{}

	public static void exitNormally()
	{
		exit(0);
	}

	public static void exitBuildFailed() throws IOException
	{
		fatalError("BUILD FAILED");
		exit(Failure);
	}

	public static void exitNormallyWithHelp(final @NotNull OptionParser optionParser)
	{
		printOptionHelp(optionParser);
		exitNormally();
	}

	public static void exitError(final @NotNull Throwable fatal)
	{
		final StringWriter writer = new StringWriter();
		fatal.printStackTrace(new PrintWriter(writer));
		fatalError(writer.toString());
		exit(Failure);
	}

	public static void exitBadOptions(final @NotNull OptionParser optionParser, final @NotNull String errorMessage)
	{
		fatalError(errorMessage);
		printOptionHelp(optionParser);
		exit(2);
	}

	@SuppressWarnings({"UseOfSystemOutOrSystemErr"})
	private static void printOptionHelp(final OptionParser optionParser)
	{
		try
		{
			optionParser.printHelpOn(out);
		}
		catch (final IOException e)
		{
			final class CouldNotPrintOptionsToStandardOutException extends IllegalStateException
			{
				public CouldNotPrintOptionsToStandardOutException()
				{
					super("Could not print options to standard out", e);
				}
			}
			throw new CouldNotPrintOptionsToStandardOutException();
		}
	}

	private static void fatalError(final @NotNull String errorMessage)
	{
		err.println(errorMessage);
	}
}

