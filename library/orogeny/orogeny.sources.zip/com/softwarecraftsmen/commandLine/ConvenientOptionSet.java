/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.commandLine;

import joptsimple.OptionParser;
import joptsimple.OptionSet;
import org.jetbrains.annotations.NotNull;
import static com.softwarecraftsmen.commandLine.ConvenientOptionParser.HelpOption;
import static com.softwarecraftsmen.commandLine.Exit.exitBadOptions;
import static com.softwarecraftsmen.commandLine.Exit.exitNormallyWithHelp;

import static java.lang.String.format;
import java.util.List;
import static java.util.Locale.UK;

public class ConvenientOptionSet
{
	public static final int ExitStatusError = 1;

	private final OptionParser optionParser;
	private final OptionSet optionSet;

	public ConvenientOptionSet(final @NotNull OptionParser optionParser, final @NotNull OptionSet optionSet)
	{
		this.optionParser = optionParser;
		this.optionSet = optionSet;
	}

	public void exitIfHelpRequested()
	{
		if (optionSet.has(HelpOption))
		{
			exitNormallyWithHelp(optionParser);
		}
	}

	@SuppressWarnings({"unchecked"})
	@NotNull
	public <T> T exitIfRequiredOptionUnavailable(final @NotNull OptionName<T> optionName)
	{
		final String option = optionName.name();
		if (!optionSet.has(option))
		{
			exitBadOptions(optionParser, format(UK, "Missing required option \"--%1$s\"", option));
		}
		if (!optionSet.hasArgument(option))
		{
			exitBadOptions(optionParser, format(UK, "Missing value for required option \"--%1$s\"", option));
		}
		return (T) optionSet.valueOf(option);
	}

	@SuppressWarnings({"unchecked"})
	@NotNull
	public <T> T defaultIfOptionalArgumentUnavailable(final @NotNull OptionName<T> optionName, final @NotNull T defaultValue)
	{
		final String option = optionName.name();
		if (!optionSet.has(option))
		{
			return defaultValue;
		}
		if (!optionSet.hasArgument(option))
		{
			return defaultValue;
		}
		return (T) optionSet.valueOf(option);
	}

	public boolean optionalBoolean(final @NotNull OptionName<Boolean> option)
	{
		return optionSet.has(option.name());
	}

	@NotNull
	public List<?> argumentsOf(final @NotNull OptionName<List<?>> option)
	{
		return optionSet.argumentsOf(option.name());
	}
}
