/**
 * This file is Copyright © 2009 Vubble Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.commandLine;

import joptsimple.ArgumentAcceptingOptionSpec;
import joptsimple.OptionParser;
import org.jetbrains.annotations.NotNull;

public class ConvenientOptionParser
{
	@NotNull
	static final String HelpOption = "help";

	private final OptionParser optionParser;
	private boolean helpCalled;

	public ConvenientOptionParser()
	{
		optionParser = new OptionParser();
		helpCalled = false;
	}

	public void help(final @NotNull String helpMessage)
	{
		optionParser.accepts(HelpOption, helpMessage);
		helpCalled = true;
	}

	@NotNull
	public <T> WrappedArgumentAcceptingOptionSpec<T> withRequiredArgument(final @NotNull OptionName<T> option, final @NotNull String description)
	{
		if (!helpCalled)
		{
			throw new IllegalStateException("Please call help() first");
		}
		return new WrappedArgumentAcceptingOptionSpec<T>(optionParser.accepts(option.name(), description).withRequiredArg());
	}

	@NotNull
	public <T> WrappedArgumentAcceptingOptionSpec<T> withOptionalArgument(final @NotNull OptionName<T> option, final @NotNull String description)
	{
		if (!helpCalled)
		{
			throw new IllegalStateException("Please call help() first");
		}
		return new WrappedArgumentAcceptingOptionSpec<T>(optionParser.accepts(option.name(), description).withOptionalArg());
	}

	@NotNull
	public ConvenientOptionSet parseAndExitWithHelpIfRequested(final @NotNull String... commandLineArguments)
	{
		final ConvenientOptionSet optionSet = new ConvenientOptionSet(optionParser, optionParser.parse(commandLineArguments));
		optionSet.exitIfHelpRequested();
		return optionSet;
	}

	public void withOptionalBoolean(final @NotNull OptionName<Boolean> option, final @NotNull String description)
	{
		if (!helpCalled)
		{
			throw new IllegalStateException("Please call help() first");
		}
		optionParser.accepts(option.name(), description);
	}

	public void exitBadOptions(final @NotNull String errorMessage)
	{
		Exit.exitBadOptions(optionParser, errorMessage);
	}

	public static class WrappedArgumentAcceptingOptionSpec<T>
	{
		private final ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec;

		private WrappedArgumentAcceptingOptionSpec(final @NotNull ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec)
		{
			this.argumentAcceptingOptionSpec = argumentAcceptingOptionSpec;
		}

		@NotNull
		public WrappedArgumentAcceptingOptionSpecOfType<T> rangeOfValues(final @NotNull String description)
		{
			return new WrappedArgumentAcceptingOptionSpecOfType<T>(argumentAcceptingOptionSpec.describedAs(description));
		}

		public static class WrappedArgumentAcceptingOptionSpecOfType<T>
		{
			private final ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec;

			private WrappedArgumentAcceptingOptionSpecOfType(final @NotNull ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec)
			{
				this.argumentAcceptingOptionSpec = argumentAcceptingOptionSpec;
			}

			public void ofType(final @NotNull Class<? extends T> type)
			{
				argumentAcceptingOptionSpec.ofType(type);
			}
		}
	}
}
