/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.outputStreamWriters;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

public interface WritableData
{
	void writeData(final @NotNull OutputStreamWriter outputStreamWriter) throws IOException;
}
