/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.outputStreamWriters;

import com.softwarecraftsmen.outputStreams.ByteArrayBufferedOutputStream;
import org.jetbrains.annotations.NotNull;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.jar.Manifest;

public class ManifestOutputStreamWriter implements OutputStreamWriter
{
	private final Manifest manifest;

	public ManifestOutputStreamWriter(final @NotNull Manifest manifest)
	{
		this.manifest = manifest;
	}

	public void write(final int outputBufferSize, final @NotNull BufferedOutputStream outputStream) throws IOException
	{
		manifest.write(outputStream);
	}

	@NotNull
	public byte[] toByteArray()
	{
		final ByteArrayBufferedOutputStream byteArrayBufferedOutputStream = new ByteArrayBufferedOutputStream(2048);
		byteArrayBufferedOutputStream.writeData(this);
		return byteArrayBufferedOutputStream.toByteArray();
	}
}
