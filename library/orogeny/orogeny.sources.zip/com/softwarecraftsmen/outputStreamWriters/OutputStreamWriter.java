/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.outputStreamWriters;

import org.jetbrains.annotations.NotNull;

import java.io.BufferedOutputStream;
import java.io.IOException;

public interface OutputStreamWriter
{
	void write(final int outputBufferSize, final @NotNull BufferedOutputStream outputStream) throws IOException;
}
