/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.executable;

import com.softwarecraftsmen.commandLine.AbstractConsoleEntryPoint;
import com.softwarecraftsmen.commandLine.ConvenientOptionSet;
import com.softwarecraftsmen.commandLine.OptionName;
import com.softwarecraftsmen.orogeny.application.Application;
import com.softwarecraftsmen.orogeny.buildLogs.Verbosity;
import com.softwarecraftsmen.orogeny.properties.Evaluatable;
import com.softwarecraftsmen.orogeny.properties.PropertyName;
import com.softwarecraftsmen.orogeny.taskNames.TaskName;
import com.softwarecraftsmen.orogeny.taskNames.TaskName.SomeTaskName;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.Arrays;
import java.util.LinkedHashMap;

import static com.softwarecraftsmen.commandLine.Exit.*;
import static com.softwarecraftsmen.commandLine.OptionName.option;
import static com.softwarecraftsmen.orogeny.buildLogs.SimpleIndentingBuildLog.consoleIndentingBuildLog;
import static com.softwarecraftsmen.orogeny.buildLogs.Verbosity.AllDetails;
import static com.softwarecraftsmen.orogeny.taskNames.TaskName.DefaultTaskName;
import static java.lang.String.format;
import static java.util.Locale.UK;

public final class ConsoleEntryPoint extends AbstractConsoleEntryPoint
{
	private static final OptionName<File> ScriptOption = option("script");
	private static final OptionName<TaskName> TaskOption = option("task");
	private static final OptionName<Verbosity> VerbosityOption = option("verbosity");

	static
	{
		help("Shows this help message");
		withRequiredArgument(ScriptOption, "Absolute or relative path to a script").rangeOfValues("/path/to/build/script").ofType(File.class);
		withOptionalArgument(TaskOption, "The task to execute (default is first non-hidden task)").rangeOfValues("mytask").ofType(SomeTaskName.class);
		withOptionalArgument(VerbosityOption, format(UK, "The verbosity %1$s", Arrays.toString(Verbosity.values()))).rangeOfValues(Arrays.toString(Verbosity.values())).ofType(Verbosity.class);
	}

	protected void entryPoint(final @NotNull ConvenientOptionSet parsedArguments)
	{
		final File script = parsedArguments.exitIfRequiredOptionUnavailable(ScriptOption);
		final TaskName taskName = parsedArguments.defaultIfOptionalArgumentUnavailable(TaskOption, DefaultTaskName);
		final Verbosity verbosity = parsedArguments.defaultIfOptionalArgumentUnavailable(VerbosityOption, AllDetails);

		if (!script.exists())
		{
			exitBadOptions("Script %1$s does not exist", script);
		}

		try
		{
			final Application application = new Application(script, taskName, consoleIndentingBuildLog(verbosity.allImpliedVerbosities()), new LinkedHashMap<PropertyName, Evaluatable>());
			final boolean allOk = application.run();
			if (allOk)
			{
				exitNormally();
			}
			exitBuildFailed();
		}
		catch (Exception e)
		{
			exitError(e);
		}
	}

	private ConsoleEntryPoint()
	{}
}
