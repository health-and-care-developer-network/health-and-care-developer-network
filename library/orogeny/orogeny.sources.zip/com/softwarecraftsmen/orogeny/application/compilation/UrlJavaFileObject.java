/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.application.compilation;

import org.jetbrains.annotations.NotNull;

import static javax.tools.JavaFileObject.Kind.CLASS;
import javax.tools.SimpleJavaFileObject;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URI;
import java.net.URISyntaxException;

public class UrlJavaFileObject extends SimpleJavaFileObject
{
	private final URL url;

	public UrlJavaFileObject(final @NotNull URL url)
	{
		super(toUri(url), CLASS);
		this.url = url;
	}

	@Override
	public InputStream openInputStream() throws IOException
	{
		return url.openStream();
	}

	@NotNull
	private static URI toUri(final @NotNull URL url)
	{
		try
		{
			return url.toURI();
		}
		catch (URISyntaxException e)
		{
			throw new IllegalStateException("Highly unlikely", e);
		}
	}
}

