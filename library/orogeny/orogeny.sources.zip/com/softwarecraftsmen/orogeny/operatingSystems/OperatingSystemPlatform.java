/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.operatingSystems;

import static com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystem.currentOperatingSystem;
import static com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystemFamily.*;
import org.jetbrains.annotations.NotNull;

public enum OperatingSystemPlatform
{
	Windows(WindowsCompatible),
	Linux(VeryPosixCompatible),
	Unix(VeryPosixCompatible),
	BSD(VeryPosixCompatible),
	MacOSX(VeryPosixCompatible),
	Unsupported(SomethingElseWeDoNotKnowAbout),
	;

	public final OperatingSystemFamily OperatingSystemFamily;

	private OperatingSystemPlatform(final @NotNull OperatingSystemFamily operatingSystemFamily)
	{
		this.OperatingSystemFamily = operatingSystemFamily;
	}

	@NotNull
	public static OperatingSystemPlatform currentOperatingSystemPlatform()
	{
		return currentOperatingSystem().OperatingSystemPlatform;
	}
}
