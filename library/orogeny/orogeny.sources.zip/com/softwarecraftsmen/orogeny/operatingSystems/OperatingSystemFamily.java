/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.operatingSystems;

import static com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystemPlatform.currentOperatingSystemPlatform;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;

public enum OperatingSystemFamily
{
	WindowsCompatible("\r\n", true),
	VeryPosixCompatible("\n", false),
	LegacyMacintosh("\r", false),
	SomethingElseWeDoNotKnowAbout("\n", false),
	;

	public final String LineSeparator;
	public final boolean hasCaseInsenstiveEnvironmentVariables;
	private static final Map<String,String> EnvironmentVariables = System.getenv();

	private OperatingSystemFamily(final @NotNull String lineSeparator, final boolean hasCaseInsenstiveEnvironmentVariables)
	{
		this.LineSeparator = lineSeparator;
		this.hasCaseInsenstiveEnvironmentVariables = hasCaseInsenstiveEnvironmentVariables;
	}

	@NotNull
	public static OperatingSystemFamily currentOperatingSystemFamily()
	{
		return currentOperatingSystemPlatform().OperatingSystemFamily;
	}

	public boolean isNotWindowsCompatible()
	{
		return this != WindowsCompatible;
	}

	@Nullable
	public String getEnvironmentVariableWithCaseSensitivityPerPlatform(final @NotNull String environmentVariableName)
	{
		for (String environmentVariableNameCased : EnvironmentVariables.keySet())
		{
			if (environmentVariableNameCased.equalsIgnoreCase(environmentVariableName))
			{
				return EnvironmentVariables.get(environmentVariableNameCased);
			}
		}
		return null;
	}
}