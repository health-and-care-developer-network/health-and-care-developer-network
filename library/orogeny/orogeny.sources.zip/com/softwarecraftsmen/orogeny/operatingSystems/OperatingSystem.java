/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.operatingSystems;

import static com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystemPlatform.*;
import org.jetbrains.annotations.NotNull;

import static java.lang.System.getProperty;

public enum OperatingSystem
{
	Linux("Linux", com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystemPlatform.Linux),
	MacOSPreOSX("Mac OS", Unsupported),
	MacOSX("Mac OS X", com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystemPlatform.MacOSX),
	Windows95("Windows 95", Unsupported),
	Windows98("Windows 98", Unsupported),
	WindowsMe("Windows Me", Unsupported),
	WindowsNT("Windows NT", Unsupported),
	Windows2000("Windows 2000", Windows),
	WindowsXP("Windows XP", Windows),
	Windows2003("Windows 2003", Windows),
	WindowsCE("Windows CE", Unsupported),
	OS2("OS/2", Unsupported),
	Solaris("Solaris", Unix),
	SunOS("SunOS", Unix),
	MPEiX("MPE/iX", Unsupported),
	HPUX("HP-UX", Unix),
	AIX("AIX", Unix),
	OS390("390", Unsupported),
	FreeBSD("FreeBSD", BSD),
	Irix("Irix", Unix),
	DigitalUnix("Digital Unix", Unix),
	Netware411("NetWare 4.11", Unsupported),
	OSF1("OSF1", Unsupported),
	OpenVMS("OpenVMS", Unsupported),
	;

	private final String osName;
	public final OperatingSystemPlatform OperatingSystemPlatform;

	// Known values from http://lopica.sourceforge.net/os.html
	private OperatingSystem(final @NotNull String osName, final @NotNull OperatingSystemPlatform operatingSystemPlatform)
	{
		this.osName = osName;
		this.OperatingSystemPlatform = operatingSystemPlatform;
	}

	@NotNull
	public static OperatingSystem currentOperatingSystem()
	{
		final String operatingSystemName = getProperty("os.name", null);
		if (operatingSystemName == null)
		{
			throw new IllegalStateException("There is no value for the System property os.name");
		}
		for (OperatingSystem operatingSystem : values())
		{
			if (operatingSystem.osName.equals(operatingSystemName))
			{
				return operatingSystem;
			}
		}
		throw new IllegalStateException("We can not understand your operating system (I do not yet know the Windows Vista os.name");
	}
}
