/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny;

import com.softwarecraftsmen.orogeny.annotations.Orogeny;
import org.jetbrains.annotations.NotNull;

import java.lang.annotation.Documented;
import static java.lang.annotation.ElementType.TYPE;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Target;

@Target(TYPE)
@Retention(RUNTIME)
@Inherited
@Documented
@Orogeny
public @interface BaseDirectory
{
	@NotNull
	String value() default ".";

	@NotNull
	public static final String BaseDirectoryProperty = "orogeny:BaseDirectory";
}
