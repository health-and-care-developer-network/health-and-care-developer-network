/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.buildLogs;

import static com.softwarecraftsmen.orogeny.buildLogs.Indentation.MessageDetailIndentation;
import static com.softwarecraftsmen.orogeny.buildLogs.Indentation.MessageIndentation;
import org.jetbrains.annotations.NotNull;

import static java.util.Arrays.asList;
import static java.util.Collections.unmodifiableSet;
import java.util.LinkedHashSet;
import java.util.Set;

public enum Verbosity
{
	Summary(MessageIndentation),
	AllDetails(MessageDetailIndentation, Summary),
	;

	private final Indentation indentation;
	private final Set<Verbosity> allImpliedVerbosities;

	private Verbosity(final @NotNull Indentation indentation, final @NotNull Verbosity... impliedVerbosities)
	{
		this.indentation = indentation;
		this.allImpliedVerbosities = unmodifiableSet(new LinkedHashSet<Verbosity>(asList(impliedVerbosities))
		{{
			add(Verbosity.this);
		}});
	}

	@NotNull
	public Indentation indentation()
	{
		return indentation;
	}

	@NotNull
	public Set<Verbosity> allImpliedVerbosities()
	{
		return allImpliedVerbosities;
	}
}
