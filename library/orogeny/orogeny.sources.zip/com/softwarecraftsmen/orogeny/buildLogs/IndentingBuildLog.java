/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.buildLogs;

import com.softwarecraftsmen.orogeny.execution.SuccessOrFailure;
import org.jetbrains.annotations.NotNull;

public interface IndentingBuildLog extends BuildLog
{
	void writeMessage(final @NotNull Indentation indentation, final @NotNull String message);

	void writeMessage(final @NotNull Indentation indentation, final @NotNull SuccessOrFailure successOrFailure);
}
