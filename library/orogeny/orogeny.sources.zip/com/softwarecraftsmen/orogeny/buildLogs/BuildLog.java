/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.buildLogs;

import org.jetbrains.annotations.NotNull;

public interface BuildLog
{
	void writeMessage(final @NotNull Verbosity verbosity, final @NotNull String message);
}
