/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.buildLogs;

import org.jetbrains.annotations.NotNull;

import java.io.PrintStream;

public enum Indentation
{
	RootIndentation(0),
	TaskIndentation(1),
	ActionIndentation(2),
	MessageIndentation(3),
	MessageDetailIndentation(4);

	private final int indentDepth;

	private Indentation(final int indentDepth)
	{
		this.indentDepth = indentDepth;
	}

	public void identation(final @NotNull PrintStream printStream, final @NotNull String indentationSequence)
	{
		for (int indentToWrite = 0; indentToWrite < indentDepth; indentToWrite++)
		{
			printStream.print(indentationSequence);
		}
	}
}
