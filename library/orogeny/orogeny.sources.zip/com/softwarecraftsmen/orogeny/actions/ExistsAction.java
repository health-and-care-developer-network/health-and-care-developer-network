/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions;

import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import com.softwarecraftsmen.orogeny.buildLogs.Verbosity;
import com.softwarecraftsmen.orogeny.execution.SuccessOrFailure;
import static com.softwarecraftsmen.orogeny.execution.SuccessOrFailure.Failure;
import static com.softwarecraftsmen.orogeny.execution.SuccessOrFailure.Success;
import static com.softwarecraftsmen.orogeny.filing.AbsoluteDirectoriesAndFiles.absoluteDirectoriesAndFiles;
import com.softwarecraftsmen.orogeny.filing.AbsolutePath;
import com.softwarecraftsmen.orogeny.filing.AbsolutePaths;
import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class ExistsAction extends AbstractAction
{
	private final AbsolutePaths toCheckExists;

	public ExistsAction(final @NotNull AbsolutePaths toCheckExists)
	{
		this.toCheckExists = toCheckExists;
	}

	@NotNull
	public String describeWhatWeDo()
	{
		return "exists";
	}

	@NotNull
	public SuccessOrFailure execute(final @NotNull BuildLog buildLog, final @NotNull BuildEnvironment buildEnvironment)
	{
		buildLog.writeMessage(Verbosity.Summary, format(UK, "About to check %1$s exists", toCheckExists));

		if (toCheckExists.exists())
		{
			return Success;
		}
		return Failure(format(UK, "%1$s does not exist", toCheckExists));
	}

	@NotNull
	public ExistsAction exists(final @NotNull AbsolutePath... absolutePaths)
	{
		return exists(absoluteDirectoriesAndFiles(absolutePaths));
	}

	@NotNull
	public ExistsAction exists(final @NotNull AbsolutePaths... absolutePaths)
	{
		return new ExistsAction(absoluteDirectoriesAndFiles(absolutePaths));
	}
}
