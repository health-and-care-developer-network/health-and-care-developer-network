/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.execute;

import org.jetbrains.annotations.NotNull;

import java.util.concurrent.Callable;

public class StoppableRunnable implements Runnable
{
	private final Callable<Boolean> loopableCode;
	private final Continue aContinue;

	public StoppableRunnable(final @NotNull Continue aContinue, final @NotNull Callable<Boolean> loopableCode)
	{
		this.loopableCode = loopableCode;
		this.aContinue = aContinue;
	}

	public final void run()
	{
		boolean continueLooping;
		do
		{
			try
			{
				continueLooping = loopableCode.call();
			}
			catch (Exception e)
			{
				throw new RuntimeException(e);
			}
		} while(aContinue.continueRunning() && continueLooping);
	}

}
