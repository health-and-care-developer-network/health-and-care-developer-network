/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.execute;

import org.jetbrains.annotations.NotNull;

import static java.lang.System.currentTimeMillis;
import static java.lang.String.format;
import java.util.Date;
import static java.util.Locale.UK;

public class ConvenientThread extends Thread
{
	public ConvenientThread(final @NotNull String name, final int priority, final boolean isDaemon, final @NotNull Runnable runnable)
	{
		super(runnable, format(UK, "%1$s created at %2$tc", name, new Date(currentTimeMillis())));
		setPriority(priority);
		setDaemon(isDaemon);
	}
}
