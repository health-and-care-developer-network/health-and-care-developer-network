/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.execute;

import com.softwarecraftsmen.orogeny.filing.Execute;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class OperatingSystemAndPathDependentExecutable implements Execute
{
	private final String executable;

	public OperatingSystemAndPathDependentExecutable(final @NotNull String executable)
	{
		this.executable = executable;
	}

	public void setExecutable(final @NotNull ProcessBuilder processBuilder)
	{
		processBuilder.command(executable);
	}

	public boolean isExecutable()
	{
		return true;
	}

	@NotNull
	public String toString()
	{
		return executable;
	}

	public boolean equals(final @Nullable Object o)
	{
		if (this == o)
		{
			return true;
		}
		if (o == null || getClass() != o.getClass())
		{
			return false;
		}

		final OperatingSystemAndPathDependentExecutable that = (OperatingSystemAndPathDependentExecutable) o;
		return executable.equals(that.executable);
	}

	public int hashCode()
	{
		return executable.hashCode();
	}

	@NotNull
	public static OperatingSystemAndPathDependentExecutable operatingSystemAndPathDependentExecutable(final @NotNull String executable)
	{
		return new OperatingSystemAndPathDependentExecutable(executable);
	}
}
