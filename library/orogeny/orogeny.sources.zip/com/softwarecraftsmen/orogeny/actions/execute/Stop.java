/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.execute;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Stop implements Continue, Stopper
{
	private final Lock readLock;
	private final Lock writeLock;
	private boolean continueRunning;

	public Stop()
	{
		final ReadWriteLock stopMeLock = new ReentrantReadWriteLock();
		readLock = stopMeLock.readLock();
		writeLock = stopMeLock.writeLock();
		continueRunning = true;
	}

	public boolean continueRunning()
	{
		final boolean continueRunning;
		readLock.lock();
		continueRunning = this.continueRunning;
		readLock.unlock();
		return continueRunning;
	}

	public void stop()
	{
		writeLock.lock();
		continueRunning = false;
		writeLock.unlock();
	}
}
