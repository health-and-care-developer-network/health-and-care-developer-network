/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions;

import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import com.softwarecraftsmen.orogeny.execution.SuccessOrFailure;
import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import org.jetbrains.annotations.NotNull;

public class RecreateDirectoryAction extends AbstractAction
{
	private final DeleteDirectoryAction deleteDirectoryDoes;
	private final MakeDirectoryAction makeDirectoryDoes;

	public RecreateDirectoryAction(final @NotNull DeleteDirectoryAction deleteDirectoryDoes, final @NotNull MakeDirectoryAction makeDirectoryDoes)
	{
		this.deleteDirectoryDoes = deleteDirectoryDoes;
		this.makeDirectoryDoes = makeDirectoryDoes;
	}

	@NotNull
	public String describeWhatWeDo()
	{
		return "recreateDirectory";
	}

	@NotNull
	public SuccessOrFailure execute(final @NotNull BuildLog buildLog, final @NotNull BuildEnvironment buildEnvironment)
	{
		final SuccessOrFailure deletion = deleteDirectoryDoes.execute(buildLog, buildEnvironment);
		if (deletion.isFailure())
		{
			return deletion;
		}
		return makeDirectoryDoes.execute(buildLog, buildEnvironment);
	}

	@NotNull
	public static RecreateDirectoryAction recreateDirectory(final @NotNull AbsoluteDirectory absoluteDirectory)
	{
		return new RecreateDirectoryAction(new DeleteDirectoryAction(absoluteDirectory), new MakeDirectoryAction(absoluteDirectory));
	}
}
