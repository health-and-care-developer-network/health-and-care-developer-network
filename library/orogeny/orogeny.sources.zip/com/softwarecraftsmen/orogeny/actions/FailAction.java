/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions;

import org.jetbrains.annotations.NotNull;
import com.softwarecraftsmen.orogeny.execution.SuccessOrFailure;
import static com.softwarecraftsmen.orogeny.execution.SuccessOrFailure.Failure;
import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import com.softwarecraftsmen.orogeny.properties.PropertyName;
import com.softwarecraftsmen.orogeny.properties.Evaluatable;
import com.softwarecraftsmen.orogeny.properties.ObjectArrayAdapterEvaluatable;
import com.softwarecraftsmen.orogeny.properties.StringAdapterEvaluatable;
import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;

public class FailAction extends AbstractAction
{
	private final Evaluatable failureMessage;

	private FailAction(final @NotNull Evaluatable failureMessage)
	{
		this.failureMessage = failureMessage;
	}

	@NotNull
	public String describeWhatWeDo()
	{
		return "fail";
	}

	@NotNull
	public SuccessOrFailure execute(final @NotNull BuildLog buildLog, final @NotNull BuildEnvironment buildEnvironment)
	{
		return Failure(failureMessage.evaluate(buildEnvironment));
	}

	@NotNull
	public static FailAction fail(final @NotNull PropertyName propertyName)
	{
		return new FailAction(propertyName);
	}

	@NotNull
	public static FailAction fail(final @NotNull String text)
	{
		return new FailAction(new StringAdapterEvaluatable(text));
	}

	@NotNull
	public static FailAction fail(final @NotNull Object... objects)
	{
		return new FailAction(new ObjectArrayAdapterEvaluatable(objects));
	}
}
