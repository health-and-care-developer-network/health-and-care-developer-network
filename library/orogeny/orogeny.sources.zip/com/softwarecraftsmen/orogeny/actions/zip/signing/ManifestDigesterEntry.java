/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.zip.signing;

import org.jetbrains.annotations.NotNull;

import java.security.MessageDigest;

public class ManifestDigesterEntry
{
	private final byte rawBytes[];
	private final int offset;
	private final int lengthWithBlankLine;

	public ManifestDigesterEntry(final @NotNull byte[] rawBytes, final int offset, final int lengthWithBlankLine)
	{
		this.rawBytes = rawBytes;
		this.offset = offset;
		this.lengthWithBlankLine = lengthWithBlankLine;
	}

	@NotNull
	public byte[] digest(final @NotNull MessageDigest messageDigest)
	{
		messageDigest.reset();
		messageDigest.update(rawBytes, offset, lengthWithBlankLine);
		return messageDigest.digest();
	}
}
