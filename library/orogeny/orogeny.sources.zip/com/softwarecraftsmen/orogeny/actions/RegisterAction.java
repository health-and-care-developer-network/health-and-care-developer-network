/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions;

import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import static com.softwarecraftsmen.orogeny.buildLogs.Verbosity.Summary;
import com.softwarecraftsmen.orogeny.execution.SuccessOrFailure;
import static com.softwarecraftsmen.orogeny.execution.SuccessOrFailure.Success;
import static com.softwarecraftsmen.orogeny.filing.AbsoluteDirectoriesAndFiles.absoluteDirectoriesAndFiles;
import com.softwarecraftsmen.orogeny.filing.AbsolutePath;
import com.softwarecraftsmen.orogeny.filing.AbsolutePaths;
import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class RegisterAction extends AbstractAction
{
	private final String name;
	private final AbsolutePaths classPath;

	public RegisterAction(final @NotNull String name, final @NotNull AbsolutePaths classPath)
	{
		this.name = name;
		this.classPath = classPath;
	}

	@NotNull
	public String describeWhatWeDo()
	{
		return "register";
	}

	@NotNull
	public SuccessOrFailure execute(final @NotNull BuildLog buildLog, final @NotNull BuildEnvironment buildEnvironment)
	{
		buildLog.writeMessage(Summary, format(UK, "About to register '%1$s' with paths '%2$s'", name, classPath));
		buildEnvironment.registerPaths(name, classPath);
		return Success;
	}

	@NotNull
	public static SpecifyName register(final @NotNull String name)
	{
		return new SpecifyName(name);
	}

	public static final class SpecifyName
	{
		private final String name;

		private SpecifyName(final @NotNull String name)
		{
			this.name = name;
		}

		@NotNull
		public RegisterAction asPaths(final @NotNull AbsolutePath... classPath)
		{
			return asPaths(absoluteDirectoriesAndFiles(classPath));
		}

		@NotNull
		public RegisterAction asPaths(final @NotNull AbsolutePaths... classPath)
		{
			return new RegisterAction(name, absoluteDirectoriesAndFiles(classPath));
		}
	}
}
