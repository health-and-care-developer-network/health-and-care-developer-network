package com.softwarecraftsmen.orogeny.actions;

import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import com.softwarecraftsmen.orogeny.execution.SuccessOrFailure;
import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import org.jetbrains.annotations.NotNull;

import static com.softwarecraftsmen.orogeny.actions.ExecuteAction.TenMinutes;
import static com.softwarecraftsmen.orogeny.actions.execute.OperatingSystemAndPathDependentExecutable.operatingSystemAndPathDependentExecutable;
import static com.softwarecraftsmen.orogeny.execution.SuccessOrFailure.Failure;
import static com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystemFamily.VeryPosixCompatible;
import static com.softwarecraftsmen.orogeny.properties.PropertyName.EnvironmentPATH;
import static java.lang.String.format;
import static java.util.Locale.UK;

/**
 * This file is Copyright © 2009 Vubble Limited. All Rights Reserved.
 */
public class DebianPackageAction extends AbstractAction
{
	@NotNull
	public static DebianPackageAction debianPackage(final @NotNull AbsoluteDirectory packageTemplatePath, final @NotNull AbsoluteDirectory gnupgHomePath)
	{
		return new DebianPackageAction(packageTemplatePath, gnupgHomePath);
	}

	private final AbsoluteDirectory packageTemplatePath;
    private final AbsoluteDirectory gnupgHomePath;

    public DebianPackageAction(final @NotNull AbsoluteDirectory packageTemplatePath, final @NotNull AbsoluteDirectory gnupgHomePath)
	{
		this.packageTemplatePath = packageTemplatePath;
        this.gnupgHomePath = gnupgHomePath;
    }

	@NotNull
	public String describeWhatWeDo()
	{
		return "debian package";
	}

	@NotNull
	public SuccessOrFailure execute(final @NotNull BuildLog buildLog, final @NotNull BuildEnvironment buildEnvironment)
	{
		if (!packageTemplatePath.exists())
		{
			return Failure(format(UK, "packageTemplatePath %1$s does not exist", packageTemplatePath));
		}

		if (!gnupgHomePath.exists())
		{
			return Failure(format(UK, "gnupgHomePath %1$s does not exist", gnupgHomePath));
		}

		packageTemplatePath.subDirectory("debian").file("rules").toFile().setExecutable(true);

        if (buildEnvironment.currentOperatingSystemFamily() != VeryPosixCompatible)
		{
			return Failure("The current operating system does not support dpkg-buildpackage");
		}
        
        final Action dpkgBuildPackage = ExecuteAction.execute(operatingSystemAndPathDependentExecutable("debuild")).inWorkingDirectory(packageTemplatePath).forUpTo(TenMinutes)
		.withInheritedEnvironmentVariables()
		.withEnvironmentVariable("PATH", buildEnvironment.getProperty(EnvironmentPATH).evaluate(buildEnvironment))
		.withEnvironmentVariable("DH_VERBOSE", "1")
        .withEnvironmentVariable("GNUPGHOME", gnupgHomePath.toFileSystemSpecificPath())
		.withArguments
		(
            "--no-conf",
            "--rootcmd=fakeroot",
            "-nc",
            "-D",
            "--lintian-opts",
            "--info",
            "--verbose",
            "--allow-root",
            "--fail-on-warnings",
            "--checksums",
            "--suppress-tags",
            "bad-distribution-in-changes-file",
            "--display-info",
            "--pedantic"
		);

		return dpkgBuildPackage.execute(buildLog, buildEnvironment);
	}
}
