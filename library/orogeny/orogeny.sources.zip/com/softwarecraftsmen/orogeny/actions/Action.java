/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions;

import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import com.softwarecraftsmen.orogeny.execution.SuccessOrFailure;
import org.jetbrains.annotations.NotNull;

public interface Action
{
	@NotNull
	String describeWhatWeDo();

	@NotNull
	SuccessOrFailure execute(final @NotNull BuildLog buildLog, final @NotNull BuildEnvironment buildEnvironment);

	@NotNull
	Action onlyIf(boolean onlyIf);

	@NotNull
	Action unless(boolean unless);
}
