/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.compilation;

import static com.softwarecraftsmen.orogeny.actions.compilation.OptionsList.dashName;
import org.jetbrains.annotations.NotNull;

import javax.tools.OptionChecker;

public abstract class OptionSupported
{
	public abstract int numberOfArguments();
	public abstract boolean isUnsupported();

	public static OptionSupported optionsSupported(final @NotNull OptionChecker optionChecker, final @NotNull String undashedName)
	{
		final String dashedName = dashName(undashedName);
		final int numberOfArguments = optionChecker.isSupportedOption(dashedName);
		if (numberOfArguments == -1)
		{
			return Unsupported;
		}
		return Supported(numberOfArguments);
	}

	private static final OptionSupported Unsupported = new OptionSupported()
	{
		public int numberOfArguments()
		{
			throw new UnsupportedOperationException("Check isUnsupported() first");
		}

		public boolean isUnsupported()
		{
			return true;
		}
	};

	private static OptionSupported Supported(final int numberOfArguments)
	{
		return new OptionSupported()
		{
			public int numberOfArguments()
			{
				return numberOfArguments;
			}

			public boolean isUnsupported()
			{
				return false;
			}
		};
	}
}
