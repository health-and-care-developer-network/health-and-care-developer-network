/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.compilation;

import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import static com.softwarecraftsmen.orogeny.buildLogs.Verbosity.Summary;
import org.jetbrains.annotations.NotNull;

import javax.tools.Diagnostic;
import javax.tools.DiagnosticListener;
import javax.tools.JavaFileObject;

public final class BuildLogDiagnosticListener implements DiagnosticListener<JavaFileObject>
{
	private final BuildLog buildLog;

	public BuildLogDiagnosticListener(final @NotNull BuildLog buildLog)
	{
		this.buildLog = buildLog;
	}

	public void report(final @NotNull Diagnostic<? extends JavaFileObject> diagnostic)
	{
		buildLog.writeMessage(Summary, diagnostic.toString());
	}
}
