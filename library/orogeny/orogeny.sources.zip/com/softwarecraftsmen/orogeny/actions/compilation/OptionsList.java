/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.compilation;

import org.jetbrains.annotations.NotNull;

import javax.tools.OptionChecker;
import java.util.ArrayList;

import static com.softwarecraftsmen.orogeny.actions.compilation.OptionSupported.optionsSupported;

// TODO: override specification of bootstrap, installed extension, endorsed standards to compile other versions
// TODO: Specify source, target versions
/*-g                         Generate all debugging info
  -g:none                    Generate no debugging info
  -g:{lines,vars,source}     Generate only some debugging info
  -nowarn                    Generate no warnings
  -verbose                   Output messages about what the compiler is doing
  -deprecation               Output source locations where deprecated APIs are used
  -classpath <path>          Specify where to find user class filing and annotation processors
  -cp <path>                 Specify where to find user class filing and annotation processors
  -sourcepath <path>         Specify where to find input source filing
  -bootclasspath <path>      Override location of bootstrap class filing
  -extdirs <dirs>            Override location of installed extensions
  -endorseddirs <dirs>       Override location of endorsed standards path
  -proc:{none,only}          Control whether annotation processing and/or compilation is done.
  -processor <class1>[,<class2>,<class3>...]Names of the annotation processors to run; bypasses default discovery process
  -processorpath <path>      Specify where to find annotation processors
  -d <directory>             Specify where to place generated class filing
  -s <directory>             Specify where to place generated source filing
  -implicit:{none,class}     Specify whether or not to generate class filing for implicitly referenced filing
  -encoding <encoding>       Specify character encoding used by source filing
  -source <release>          Provide source compatibility with specified release
  -target <release>          Generate class filing for specific VM version
  -version                   Version information
  -help                      Print a synopsis of standard options
  -Akey[=value]              Options to pass to annotation processors
  -X                         Print a synopsis of nonstandard options
  -J<flag>                   Pass <flag> directly to the runtime system

  -Xlint                     Enable recommended warnings
  -Xlint:{all,cast,deprecation,divzero,empty,unchecked,fallthrough,path,serial,finally,overrides,-cast,-deprecation,-divzero,-empty,-unchecked,-fallthrough,-path,-serial,-finally,-overrides,none}Enable or disable specific warnings
  -Xbootclasspath/p:<path>   Prepend to the bootstrap class path
  -Xbootclasspath/a:<path>   Append to the bootstrap class path
  -Xbootclasspath:<path>     Override location of bootstrap class filing
  -Djava.ext.dirs=<dirs>     Override location of installed extensions
  -Djava.endorsed.dirs=<dirs>Override location of endorsed standards path
  -Xmaxerrs <number>         Set the maximum number of errors to print
  -Xmaxwarns <number>        Set the maximum number of warnings to print
  -Xstdout <filename>        Redirect standard output
  -Xprint                    Print out a textual representation of specified types
  -XprintRounds              Print information about rounds of annotation processing
  -XprintProcessorInfo       Print information about which annotations a processor is asked to process
  -Xprefer:{source,newer}    Specify which file to read when both a source file and class file are found for an implicitly compiled class
*/
public class OptionsList extends ArrayList<String>
{
	private final OptionChecker optionChecker;

	public OptionsList(final @NotNull OptionChecker optionChecker)
	{
		this.optionChecker = optionChecker;
	}

	public void version7()
	{
		addOption("source", "1.7");
		addOption("target", "1.7");
	}

	public void generateDebuggingInformation()
	{
		addOption("g");
	}

	public void generateDeprecationMessages()
	{
		addOption("deprecation");
	}

	public void generateWarnings()
	{
		addOption("Xlint");
	}

	public void disableSerialWarnings()
	{
		addOption("Xlint:-serial");
	}

	public void disableUncheckedWarnings()
	{
		addOption("Xlint:-unchecked");
	}

	@SuppressWarnings({"ManualArrayToCollectionCopy"})
	public void addOption(final @NotNull String undashedName, final @NotNull String... values)
	{
		if (optionsSupported(optionChecker, undashedName).isUnsupported())
		{
			return;
		}
		addOptionNamed(undashedName);
		for (String value : values)
		{
			add(value);
		}
	}

	private void addOptionNamed(final String name)
	{
		add(dashName(name));
	}

	@NotNull
	public static String dashName(final @NotNull String name) {return "-" + name;}
}
