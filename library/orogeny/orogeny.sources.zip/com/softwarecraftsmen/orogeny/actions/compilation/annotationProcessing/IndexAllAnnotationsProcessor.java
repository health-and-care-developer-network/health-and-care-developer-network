/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.compilation.annotationProcessing;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.element.*;
import javax.lang.model.type.ArrayType;
import javax.lang.model.type.DeclaredType;
import javax.lang.model.type.PrimitiveType;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.SimpleElementVisitor6;
import javax.lang.model.util.SimpleTypeVisitor6;
import javax.tools.FileObject;
import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.util.*;
import java.util.Map.Entry;

import static java.lang.String.format;
import static java.util.Locale.UK;
import static javax.lang.model.SourceVersion.RELEASE_7;
import static javax.lang.model.element.ElementKind.*;
import static javax.tools.Diagnostic.Kind.ERROR;
import static javax.tools.Diagnostic.Kind.WARNING;
import static javax.tools.StandardLocation.CLASS_OUTPUT;

@SupportedAnnotationTypes("*")
@SupportedSourceVersion(RELEASE_7)
public class IndexAllAnnotationsProcessor extends AbstractProcessor
{
	private final Map<ElementKind, MultiValueMap<String, ?>> annotationsToOccurences;

	@NotNull
	public static IndexAllAnnotationsProcessor indexAllAnnotations()
	{
		return new IndexAllAnnotationsProcessor();
	}

	private IndexAllAnnotationsProcessor()
	{
		super();
		annotationsToOccurences = new LinkedHashMap<ElementKind, MultiValueMap<String, ?>>()
		{{
			put(PACKAGE, new MultiValueMap<String, String>());
			put(CLASS, new MultiValueMap<String, String>());
			put(ENUM, new MultiValueMap<String, String>());
			put(INTERFACE, new MultiValueMap<String, String>());
			put(ANNOTATION_TYPE, new MultiValueMap<String, String>());
			put(FIELD, new MultiValueMap<String, Map<String, String>>());
			put(CONSTRUCTOR, new MultiValueMap<String, Map<String, ?>>());
			put(INSTANCE_INIT, new MultiValueMap<String, Map<String, ?>>());
			put(STATIC_INIT, new MultiValueMap<String, Map<String, ?>>());
			put(METHOD, new MultiValueMap<String, Map<String, ?>>());
		}};
	}

	public boolean process(final @NotNull Set<? extends TypeElement> supportedAnnotations, final @NotNull RoundEnvironment roundEnvironment)
	{
		for (final TypeElement annotation : supportedAnnotations)
		{
			final String annotationName = annotation.getQualifiedName().toString();
			for (final Element element : roundEnvironment.getElementsAnnotatedWith(annotation))
			{
				element.accept(new SimpleElementVisitor6<Void, Void>()
				{
					@SuppressWarnings({"unchecked"})
					@Nullable
					public Void visitPackage(final @NotNull PackageElement packageElement, final @Nullable Void nothing)
					{
						if (packageElement.isUnnamed())
						{
							reportWarning("It does not make sense to define annotations for the default package");
							return nothing;
						}
						final MultiValueMap<String, String> map = (MultiValueMap<String, String>) annotationsToOccurences.get(PACKAGE);
						map.put(annotationName, packageElement.getQualifiedName().toString());
						return nothing;
					}

					@SuppressWarnings({"unchecked"})
					@Nullable
					public Void visitType(final @NotNull TypeElement typeElement, final @Nullable Void nothing)
					{
						final String typeName = typeElement.getQualifiedName().toString();
						if (!annotationsToOccurences.containsKey(typeElement.getKind()))
						{
							reportError(typeElement, format(UK, "TypeElement %1$s is not a Class, Enum, Interface or Annotation", typeElement));
							return nothing;
						}
						final MultiValueMap<String, String> map = (MultiValueMap<String, String>) annotationsToOccurences.get(typeElement.getKind());
						map.put(annotationName, typeName);
						return nothing;
					}

					@SuppressWarnings({"unchecked"})
					@Nullable
					public Void visitVariable(final @NotNull VariableElement variableElement, final @Nullable Void nothing)
					{
						// Field, enum constant, method or constructor parameter, local variable or exception parameter
						// TODO: Record enclosing class, and whether static or non-static!
						final ElementKind elementKind = variableElement.getKind();
						if (!elementKind.isField())
						{
							return nothing;
						}
						final MultiValueMap<String, Map<String, String>> map = (MultiValueMap<String, Map<String, String>>) annotationsToOccurences.get(elementKind);
						final Map<String, String> details = new LinkedHashMap<String, String>();
						details.put("class", ((TypeElement) variableElement.getEnclosingElement()).getQualifiedName().toString());
						details.put("field", variableElement.getSimpleName().toString());
						map.put(annotationName, details);
						return nothing;
					}

					@SuppressWarnings({"unchecked"})
					@Nullable
					public Void visitExecutable(final @NotNull ExecutableElement executableElement, final @Nullable Void nothing)
					{
						final MultiValueMap<String, Map<String, ?>> placeToRecord = (MultiValueMap<String, Map<String, ?>>) annotationsToOccurences.get(executableElement.getKind());
						if (placeToRecord == null)
						{
							reportError(executableElement, format(UK, "ExecutableElement %1$s is not a Constructor, Instance Initializer, Static Initializer or Method", executableElement));
							return nothing;
						}

						final List<String> parameters = new ArrayList<String>();
						for (VariableElement variableElement : executableElement.getParameters())
						{
							final StringWriter typeNameWriter = new StringWriter();
							variableElement.asType().accept(new SimpleTypeVisitor6<Void, Void>()
							{
								@Nullable
								public Void visitArray(final @NotNull ArrayType arrayType, final @Nullable Void nothing)
								{
									final TypeMirror componentType = arrayType.getComponentType();
									componentType.accept(this, nothing);
									typeNameWriter.write("[]");
									return nothing;
								}

								@Nullable
								public Void visitPrimitive(final @NotNull PrimitiveType primitiveType, final @Nullable Void nothing)
								{
									typeNameWriter.write(primitiveType.toString());
									return nothing;
								}

								@Nullable
								public Void visitDeclared(final @NotNull DeclaredType declaredType, final @Nullable Void nothing)
								{
									typeNameWriter.write(((TypeElement) declaredType.asElement()).getQualifiedName().toString());
									return nothing;
								}
							}, null);
							parameters.add(typeNameWriter.toString());
						}

						final Map<String, Object> details = new LinkedHashMap<String, Object>();
						details.put("class", ((TypeElement) executableElement.getEnclosingElement()).getQualifiedName().toString());
						details.put("method", executableElement.getSimpleName().toString());
						details.put("parameters", parameters);

						placeToRecord.put(annotationName, details);
						return nothing;
					}
				}, null);
			}
		}

		if (roundEnvironment.processingOver())
		{
			writeIndex(supportedAnnotations);
		}
		return false;
	}

	private void writeIndex(final Set<? extends TypeElement> supportedAnnotations)
	{
		final FileObject resource;
		try
		{
			resource = processingEnv.getFiler().createResource(CLASS_OUTPUT, "", "META-INF/allAnnotationsIndex.xml", supportedAnnotations.toArray(new Element[supportedAnnotations.size()]));
		}
		catch (IOException e)
		{
			reportError("Could not create annotations index");
			return;
		}

		final OutputStream outputStream;
		try
		{
			outputStream = new BufferedOutputStream(resource.openOutputStream());
		}
		catch (IOException e)
		{
			reportError("Could not open outputStream for annotations index");
			return;
		}

		try
		{
			reallyWriteIndex(outputStream);
		}
		catch (IOException e)
		{
			reportError("Could not write to annotations index");
		}
		finally
		{
			try
			{
				outputStream.close();
			}
			catch (IOException e)
			{
				reportError("Could not close outputStream for annotations index");
			}
		}
	}

	private void reallyWriteIndex(final OutputStream outputStream) throws IOException
	{
		final Map<String, Map> allEntries = new LinkedHashMap<String, Map>();
		for (Entry<ElementKind, MultiValueMap<String, ?>> entry : annotationsToOccurences.entrySet())
		{
			allEntries.put(entry.getKey().name(), entry.getValue().internalMap);
		}

		final XMLEncoder objectWriter = new XMLEncoder(outputStream);
		//final ObjectOutputStream objectWriter = new ObjectOutputStream(outputStream);
		objectWriter.writeObject(allEntries);
		objectWriter.close();
	}

	private void reportError(final String message) {processingEnv.getMessager().printMessage(ERROR, message);}

	private void reportError(final Element element, final String message) {processingEnv.getMessager().printMessage(ERROR, message, element);}

	private void reportWarning(final String message) {processingEnv.getMessager().printMessage(WARNING, message);}

	public static final class MultiValueMap<K, V>
	{
		public interface MapVisitor<K, V>
		{
			void visit(final @NotNull K key, final @NotNull V value);
		}

		private final LinkedHashMap<K, Set<V>> internalMap;

		public MultiValueMap()
		{
			internalMap = new LinkedHashMap<K, Set<V>>();
		}

		public void iterate(final @NotNull MapVisitor<K, Set<V>> mapVisitor)
		{
			for (Entry<K, Set<V>> entry : internalMap.entrySet())
			{
				mapVisitor.visit(entry.getKey(), entry.getValue());
			}
		}

		public void put(final @NotNull K key, final @NotNull V value)
		{
			final Set<V> valuesAtKey = valuesAtKey(key);
			valuesAtKey.add(value);
			internalMap.put(key, valuesAtKey);
		}

		public boolean equals(final @Nullable Object o)
		{
			if (this == o)
			{
				return true;
			}
			if (o == null || getClass() != o.getClass())
			{
				return false;
			}

			final MultiValueMap that = (MultiValueMap) o;
			return internalMap.equals(that.internalMap);
		}

		public int hashCode()
		{
			return internalMap.hashCode();
		}

		@NotNull
		public String toString()
		{
			return internalMap.toString();
		}

		private Set<V> valuesAtKey(final K key)
		{
			return (internalMap.containsKey(key)) ? internalMap.get(key) : new LinkedHashSet<V>();
		}
	}

}
