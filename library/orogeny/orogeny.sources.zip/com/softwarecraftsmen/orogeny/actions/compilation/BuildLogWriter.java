/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions.compilation;

import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import static com.softwarecraftsmen.orogeny.buildLogs.Verbosity.AllDetails;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

public final class BuildLogWriter extends Writer
{
	private final BuildLog buildLog;

	public BuildLogWriter(final @NotNull BuildLog buildLog)
	{
		this.buildLog = buildLog;
	}

	public void write(final char[] buffer, final int offset, final int length) throws IOException
	{
		final StringWriter writer = new StringWriter();
		writer.write(buffer, offset, length);
		writer.flush();
		writer.close();
		buildLog.writeMessage(AllDetails, writer.toString());
	}

	public void flush() throws IOException
	{
	}

	public void close() throws IOException
	{
	}
}
