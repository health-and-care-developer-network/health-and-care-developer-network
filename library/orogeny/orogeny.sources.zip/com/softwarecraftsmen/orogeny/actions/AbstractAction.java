package com.softwarecraftsmen.orogeny.actions;

import org.jetbrains.annotations.NotNull;
import com.softwarecraftsmen.orogeny.execution.SuccessOrFailure;
import static com.softwarecraftsmen.orogeny.execution.SuccessOrFailure.Success;
import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;

public abstract class AbstractAction implements Action
{
	@NotNull
	public String toString()
	{
		return describeWhatWeDo();
	}

	@NotNull
	public Action onlyIf(final boolean onlyIf)
	{
		if (onlyIf)
		{
			return this;
		}
		else
		{
			return new AbstractAction()
			{
				@NotNull
				public String describeWhatWeDo()
				{
					return AbstractAction.this.describeWhatWeDo() + " ignored";
				}

				@NotNull
				public SuccessOrFailure execute(final @NotNull BuildLog buildLog, final @NotNull BuildEnvironment buildEnvironment)
				{
					return Success;
				}
			};
		}
	}

	@NotNull
	public Action unless(final boolean unless)
	{
		return onlyIf(!unless);
	}
}
