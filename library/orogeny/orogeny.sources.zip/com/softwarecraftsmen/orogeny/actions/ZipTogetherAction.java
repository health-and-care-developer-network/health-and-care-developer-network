/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions;

import static com.softwarecraftsmen.orogeny.actions.JarTogetherAction.jarTogether;
import static com.softwarecraftsmen.orogeny.filing.AbsoluteDirectoriesAndFiles.absoluteDirectoriesAndFiles;
import com.softwarecraftsmen.orogeny.filing.AbsoluteFile;
import com.softwarecraftsmen.orogeny.filing.AbsolutePath;
import com.softwarecraftsmen.orogeny.filing.AbsolutePaths;
import com.softwarecraftsmen.orogeny.filing.findFileFilters.FindFilesFilter;
import org.jetbrains.annotations.NotNull;

public final class ZipTogetherAction
{
	private ZipTogetherAction()
	{}

	@NotNull
	public static SpecifyZipPath zipTogether(final @NotNull AbsolutePath... zipPath)
	{
		return zipTogether(absoluteDirectoriesAndFiles(zipPath));
	}

	@NotNull
	public static SpecifyZipPath zipTogether(final @NotNull AbsolutePaths zipPath)
	{
		return new SpecifyZipPath(zipPath);
	}

	public static final class SpecifyZipPath
	{
		private final AbsolutePaths zipPath;

		private SpecifyZipPath(final @NotNull AbsolutePaths zipPath) {this.zipPath = zipPath;}

		public SpecifyZipAndJarFiles capturing(final FindFilesFilter zipAndJarFiles)
		{
			return new SpecifyZipAndJarFiles(zipAndJarFiles);
		}

		public final class SpecifyZipAndJarFiles
		{
			private final FindFilesFilter zipAndJarFiles;

			private SpecifyZipAndJarFiles(final @NotNull FindFilesFilter zipAndJarFiles) {this.zipAndJarFiles = zipAndJarFiles;}

			public JarTogetherAction to(final @NotNull AbsoluteFile zipFile)
			{
				return jarTogether(zipPath).capturing(zipAndJarFiles).to(zipFile).withoutClassPath().withoutMainClass();
			}
		}
	}
}