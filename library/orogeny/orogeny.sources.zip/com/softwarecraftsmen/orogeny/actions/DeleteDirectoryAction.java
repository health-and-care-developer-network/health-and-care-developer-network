/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.actions;

import com.softwarecraftsmen.orogeny.buildLogs.BuildLog;
import static com.softwarecraftsmen.orogeny.buildLogs.Verbosity.Summary;
import com.softwarecraftsmen.orogeny.execution.SuccessOrFailure;
import static com.softwarecraftsmen.orogeny.execution.SuccessOrFailure.Failure;
import static com.softwarecraftsmen.orogeny.execution.SuccessOrFailure.Success;
import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import com.softwarecraftsmen.orogeny.filing.FilingOperationFailedException;
import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class DeleteDirectoryAction extends AbstractAction
{
	private final AbsoluteDirectory directory;

	public DeleteDirectoryAction(final @NotNull AbsoluteDirectory directory)
	{
		this.directory = directory;
	}

	@NotNull
	public String describeWhatWeDo()
	{
		return "deleteDirectory";
	}

	@NotNull
	public SuccessOrFailure execute(final @NotNull BuildLog buildLog, final @NotNull BuildEnvironment buildEnvironment)
	{
		buildLog.writeMessage(Summary, format(UK, "About to delete directory %1$s", directory));
		if (!directory.exists())
		{
			return Success;
		}
		try
		{
			directory.delete();
		}
		catch (FilingOperationFailedException e)
		{
			return Failure(format(UK, "Directory %1$s could not be deleted because %2$s", directory, e.getMessage()));
		}
		return Success;

	}

	@NotNull
	public static DeleteDirectoryAction deleteDirectory(final @NotNull AbsoluteDirectory directory)
	{
		return new DeleteDirectoryAction(directory);
	}
}