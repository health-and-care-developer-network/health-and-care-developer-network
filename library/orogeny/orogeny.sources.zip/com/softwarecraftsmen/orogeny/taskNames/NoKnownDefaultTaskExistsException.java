/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.taskNames;

import com.softwarecraftsmen.orogeny.BuildScript.BuildSyntaxException;

public class NoKnownDefaultTaskExistsException extends BuildSyntaxException
{
	public NoKnownDefaultTaskExistsException()
	{
		super("There is no known default task; all tasks are hidden");
	}
}
