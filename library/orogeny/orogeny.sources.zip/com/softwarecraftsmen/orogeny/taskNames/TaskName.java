/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.taskNames;

import com.softwarecraftsmen.orogeny.Task;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;

public abstract class TaskName
{
	@NotNull
	public abstract Task selectTask(final @NotNull Map<TaskName, Task> allTasks);

	@NotNull
	public static final TaskName DefaultTaskName = new TaskName()
	{
		@NotNull
		public Task selectTask(final @NotNull Map<TaskName, Task> allTasks)
		{
			for (Task task : allTasks.values())
			{
				if (task.isVisible())
				{
					return task;
				}
			}
			throw new NoKnownDefaultTaskExistsException();
		}

		@NotNull
		public String toString()
		{
			return "<Default>";
		}
	};

	@NotNull
	public static SomeTaskName taskName(final @NotNull String taskName)
	{
		return new SomeTaskName(taskName);
	}

	public static final class SomeTaskName extends TaskName
	{
		private final String taskName;

		public SomeTaskName(final @NotNull String taskName)
		{
			this.taskName = taskName;
		}

		@NotNull
		public Task selectTask(final @NotNull Map<TaskName, Task> allTasks)
		{
			if (!allTasks.containsKey(this))
			{
				throw new NoKnownTaskExistsException(taskName);
			}
			return allTasks.get(this);
		}

		@NotNull
		public String toString()
		{
			return taskName;
		}

		public boolean equals(final @Nullable Object o)
		{
			if (this == o)
			{
				return true;
			}
			if (o == null || getClass() != o.getClass())
			{
				return false;
			}

			final SomeTaskName that = (SomeTaskName) o;
			return taskName.equals(that.taskName);
		}

		public int hashCode()
		{
			return taskName.hashCode();
		}
	}
}
