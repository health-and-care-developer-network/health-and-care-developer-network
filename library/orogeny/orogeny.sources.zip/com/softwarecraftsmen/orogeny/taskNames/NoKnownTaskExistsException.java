/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.taskNames;

import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class NoKnownTaskExistsException extends IllegalArgumentException
{
	public NoKnownTaskExistsException(final @NotNull String taskName)
	{
		super(format(UK, "There is no known task named %1$s in the build script", taskName));
	}
}
