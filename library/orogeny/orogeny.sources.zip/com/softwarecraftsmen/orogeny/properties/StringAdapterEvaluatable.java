/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.properties;

import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import com.softwarecraftsmen.orogeny.properties.Evaluatable;
import org.jetbrains.annotations.NotNull;

public final class StringAdapterEvaluatable implements Evaluatable
{
	private final String string;

	public StringAdapterEvaluatable(final @NotNull String string)
	{
		this.string = string;
	}

	@NotNull
	public String evaluate(final @NotNull BuildEnvironment buildEnvironment)
	{
		return string;
	}
}
