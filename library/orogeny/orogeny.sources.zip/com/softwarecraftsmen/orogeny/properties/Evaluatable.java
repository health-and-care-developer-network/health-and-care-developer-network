/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.properties;

import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import org.jetbrains.annotations.NotNull;

public interface Evaluatable
{
	@NotNull
	String evaluate(final @NotNull BuildEnvironment buildEnvironment);
}
