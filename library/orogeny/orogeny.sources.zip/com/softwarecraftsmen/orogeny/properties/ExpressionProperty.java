/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.properties;

import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import org.jetbrains.annotations.NotNull;

public class ExpressionProperty implements Evaluatable
{
	private final PropertyName propertyName;
	private final PropertyExpression propertyExpression;

	public ExpressionProperty(final @NotNull PropertyName propertyName, final @NotNull PropertyExpression propertyExpression)
	{
		this.propertyName = propertyName;
		this.propertyExpression = propertyExpression;
	}

	@NotNull
	public String evaluate(final @NotNull BuildEnvironment buildEnvironment)
	{
		return propertyExpression.evaluate(buildEnvironment);
	}

	@NotNull
	public String toString()
	{
		return propertyName.toString();
	}
}