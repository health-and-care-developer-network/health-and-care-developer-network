/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.properties;

import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import com.softwarecraftsmen.orogeny.properties.Evaluatable;
import org.jetbrains.annotations.NotNull;

import java.io.StringWriter;

public final class ObjectArrayAdapterEvaluatable implements Evaluatable
{
	private final Object[] objects;

	public ObjectArrayAdapterEvaluatable(final @NotNull Object... objects)
	{
		this.objects = objects;
	}

	@NotNull
	public String evaluate(final @NotNull BuildEnvironment buildEnvironment)
	{
		final StringWriter writer = new StringWriter();
		boolean afterFirst = false;
		for (Object object : objects)
		{
			if (afterFirst)
			{
				writer.write(" ");
			}
			afterFirst = true;
			writer.write(object.toString());
		}
		return writer.toString();
	}
}