/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.properties;

import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public enum PropertyNamePrefix
{
	environment("environment"),
	system("system"),
	commandline("commandline"),
	orogeny("orogeny"),
	dynamic("dynamic");
	private final String prefix;

	private PropertyNamePrefix(final @NotNull String prefix)
	{
		this.prefix = prefix;
	}

	@NotNull
	public static PropertyNamePrefix fromName(final @NotNull String prefixedName, final int index)
	{
		if (index == -1)
		{
			return dynamic;
		}
		final String prefix = prefixedName.substring(0, index);
		for (PropertyNamePrefix propertyNamePrefix : values())
		{
			if (propertyNamePrefix.prefix.equals(prefix))
			{
				return propertyNamePrefix;
			}
		}
		throw new IllegalArgumentException(format(UK, "The prefix %1$s in %2$s is unrecognised", prefix, prefixedName));
	}

	@NotNull
	public PropertyName property(final @NotNull String name)
	{
		return new PropertyName(this, name);
	}

	public boolean isDynamic()
	{
		return this == dynamic;
	}
}
