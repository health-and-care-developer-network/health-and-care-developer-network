/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.properties;

import com.softwarecraftsmen.orogeny.buildEnvironments.BuildEnvironment;
import org.jetbrains.annotations.NotNull;

public class FixedValueProperty implements Evaluatable
{
	private final String value;

	public FixedValueProperty(final @NotNull String value)
	{
		this.value = value;
	}

	@NotNull
	public String toString()
	{
		return value;
	}

	@NotNull
	public String evaluate(@NotNull final BuildEnvironment buildEnvironment)
	{
		return value;
	}
}
