/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Locale;

public class CouldNotMoveException extends FilingOperationFailedException
{
	public CouldNotMoveException(final @NotNull AbsoluteFile original, final @NotNull AbsoluteFile destination, final @NotNull IOException cause)
	{
		super(String.format(Locale.UK, "Could not move %1$s to %2$s", original, destination), cause);
	}

	public CouldNotMoveException(final @NotNull AbsoluteFile original, final @NotNull AbsoluteFile destination, final @NotNull FilingOperationFailedException cause)
	{
		super(String.format(Locale.UK, "Could not move %1$s to %2$s", original, destination), cause);
	}
}
