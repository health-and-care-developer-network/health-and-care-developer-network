/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.posixPermissions;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class FixedReadOnlyPosixClassPermissions implements PosixClassPermissions
{
	private final boolean canRead;
	private final boolean canWrite;
	private final boolean canExecuteOrCanSearchInDirectory;

	@NotNull
	public static PosixClassPermissions Read = new FixedReadOnlyPosixClassPermissions(true, false, false);

	@NotNull
	public static PosixClassPermissions ReadWrite = new FixedReadOnlyPosixClassPermissions(true, true, false);

	@NotNull
	public static PosixClassPermissions ReadWriteExecute = new FixedReadOnlyPosixClassPermissions(true, true, true);

	@NotNull
	public static PosixClassPermissions ReadCanSearchInDirectory = new FixedReadOnlyPosixClassPermissions(true, false, true);

	public FixedReadOnlyPosixClassPermissions(final boolean canRead, final boolean canWrite, final boolean canExecuteOrCanSearchInDirectory)
	{
		this.canRead = canRead;
		this.canWrite = canWrite;
		this.canExecuteOrCanSearchInDirectory = canExecuteOrCanSearchInDirectory;
	}

	public boolean canRead()
	{
		return canRead;
	}

	public boolean canWrite()
	{
		return canWrite;
	}

	public boolean canExecuteOrCanSearchInDirectory()
	{
		return canExecuteOrCanSearchInDirectory;
	}

	@NotNull
	public String toString()
	{
		return format(UK, "canRead:%1$s, canWrite:%2$s, canExecuteOrCanSearchInDirectory:%3$s", canRead(), canWrite(), canExecuteOrCanSearchInDirectory());
	}

	public boolean equals(final @Nullable Object o)
	{
		if (this == o)
		{
			return true;
		}
		if (o == null || getClass() != o.getClass())
		{
			return false;
		}

		final FixedReadOnlyPosixClassPermissions that = (FixedReadOnlyPosixClassPermissions) o;
		return canExecuteOrCanSearchInDirectory == that.canExecuteOrCanSearchInDirectory && canRead == that.canRead && canWrite == that.canWrite;
	}

	public int hashCode()
	{
		int result;
		result = (canRead ? 1 : 0);
		result = 31 * result + (canWrite ? 1 : 0);
		result = 31 * result + (canExecuteOrCanSearchInDirectory ? 1 : 0);
		return result;
	}
}