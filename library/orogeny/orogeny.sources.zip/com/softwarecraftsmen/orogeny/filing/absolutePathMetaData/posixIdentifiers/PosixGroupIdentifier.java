/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.posixIdentifiers;

import org.jetbrains.annotations.NotNull;

import static java.lang.System.getProperty;

public class PosixGroupIdentifier extends AbstractPosixIdentifier
{
	@NotNull
	public static final PosixGroupIdentifier RootGroupIdentifier = new PosixGroupIdentifier(0, RootUserName, false);
	public static final PosixGroupIdentifier UnknownGroupIdentifier = new PosixGroupIdentifier(-1, "nogroup", true);

	private PosixGroupIdentifier(final long identifier, final @NotNull String name, final boolean unknown)
	{
		super(identifier, name, unknown);
	}

	@NotNull
	public static PosixGroupIdentifier group(final long identifier, final @NotNull String name)
	{
		if (identifier == 0 || name.equals(RootUserName))
		{
			return RootGroupIdentifier;
		}
		return new PosixGroupIdentifier(identifier, name, false);
	}

	@NotNull
	public static PosixGroupIdentifier groupBestGuessBasedOnCurrentUserButIdentifierWillBeWrong()
	{
		final String userName = getProperty("user.name", RootUserName);
		return group(BestGuessIdentifier, userName);
	}
}