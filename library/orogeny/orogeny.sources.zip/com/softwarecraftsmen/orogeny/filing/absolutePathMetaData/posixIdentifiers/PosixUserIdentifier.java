/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.posixIdentifiers;

import org.jetbrains.annotations.NotNull;

import static java.lang.System.getProperty;

public class PosixUserIdentifier extends AbstractPosixIdentifier
{
	@NotNull
	public static final PosixUserIdentifier RootUserIdentifier = new PosixUserIdentifier(0, RootUserName, false);
	public static final PosixUserIdentifier UnknownUserIdentifier = new PosixUserIdentifier(-2, "nobody", true);

	private PosixUserIdentifier(final long identifier, final @NotNull String name, final boolean unknown)
	{
		super(identifier, name, unknown);
	}

	@NotNull
	public static PosixUserIdentifier user(final long identifier, final @NotNull String name)
	{
		if (identifier == 0 || name.equals(RootUserName))
		{
			return RootUserIdentifier;
		}
		return new PosixUserIdentifier(identifier, name, false);
	}

	@NotNull
	public static PosixUserIdentifier userBestGuessBasedOnCurrentUserButIdentifierWillBeWrong()
	{
		final String userName = getProperty("user.name", RootUserName);
		return user(BestGuessIdentifier, userName);
	}
}