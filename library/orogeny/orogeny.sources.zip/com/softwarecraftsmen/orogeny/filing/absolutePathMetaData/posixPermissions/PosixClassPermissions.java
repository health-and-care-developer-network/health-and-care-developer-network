/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.posixPermissions;

public interface PosixClassPermissions
{
	boolean canRead();

	boolean canWrite();

	boolean canExecuteOrCanSearchInDirectory();
}
