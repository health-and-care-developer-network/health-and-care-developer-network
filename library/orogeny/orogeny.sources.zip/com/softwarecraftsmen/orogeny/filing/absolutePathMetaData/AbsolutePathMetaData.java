/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.absolutePathMetaData;

import com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.posixIdentifiers.PosixGroupIdentifier;
import com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.posixIdentifiers.PosixUserIdentifier;
import com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.posixPermissions.PosixClassPermissions;
import org.jetbrains.annotations.NotNull;

public interface AbsolutePathMetaData
{
	long sizeInBytes();

	long modificationTimeInMillisecondsSince1970();

	@NotNull
	PosixUserIdentifier owner();

	@NotNull
	PosixClassPermissions ownerPermissions();

	@NotNull
	PosixGroupIdentifier group();

	@NotNull
	PosixClassPermissions groupPermissions();

	@NotNull
	PosixClassPermissions othersPermissions();
}
