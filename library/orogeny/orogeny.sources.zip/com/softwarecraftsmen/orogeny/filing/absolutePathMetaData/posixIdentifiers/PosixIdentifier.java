/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.posixIdentifiers;

import org.jetbrains.annotations.NotNull;

public interface PosixIdentifier
{
	long identifier();

	@NotNull
	String name();

	boolean unknown();
}
