/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.posixPermissions;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import static java.lang.String.format;
import static java.util.Locale.UK;

public class DynamicBestGuessPosixClassPermissions implements PosixClassPermissions
{
	private final File file;

	public DynamicBestGuessPosixClassPermissions(final @NotNull File file)
	{
		this.file = file;
	}

	public boolean canRead()
	{
		guardExists();
		return file.canRead();
	}

	public boolean canWrite()
	{
		guardExists();
		return file.canWrite();
	}

	public boolean canExecuteOrCanSearchInDirectory()
	{
		guardExists();
		return file.canExecute();
	}

	private void guardExists()
	{
		if (!file.exists())
		{
			throw new IllegalStateException(format(UK, "Check that the backing file %1$s exists first!", file));
		}
	}
}
