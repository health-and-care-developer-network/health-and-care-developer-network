/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

public class Experiment
{
	// Support paths natively. This is essential. A Directory most map to a set of directories
	// A Directory can be relative or absolute.
	// A path contains a fileset

	// A Fileset most have a selection criterion / ia
	// Includes or excludes subfolders?
	// File transforms (.java => .class)?

	// wget / curl support


}
