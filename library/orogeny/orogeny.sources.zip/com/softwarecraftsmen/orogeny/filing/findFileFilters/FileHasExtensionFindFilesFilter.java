/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.findFileFilters;

import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import com.softwarecraftsmen.orogeny.filing.FileName;
import com.softwarecraftsmen.orogeny.filing.RelativeDirectory;
import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class FileHasExtensionFindFilesFilter extends AbstractFindFilesFilter
{
	protected final String extensionExcludingPeriod;

	private FileHasExtensionFindFilesFilter(final @NotNull String extensionExcludingPeriod)
	{
		this.extensionExcludingPeriod = extensionExcludingPeriod;
	}

	@NotNull
	public static FileHasExtensionFindFilesFilter fileHasExtension(final @NotNull String extensionExcludingPeriod)
	{
		return new FileHasExtensionFindFilesFilter(extensionExcludingPeriod);
	}

	public boolean include(final @NotNull AbsoluteDirectory root, final @NotNull RelativeDirectory relativeDirectory, final @NotNull FileName fileName)
	{
		return fileName.hasExtension(extensionExcludingPeriod);
	}

	@NotNull
	public String toString()
	{
		return format(UK, "FileHasExtension(%1$s)", extensionExcludingPeriod);
	}
}
