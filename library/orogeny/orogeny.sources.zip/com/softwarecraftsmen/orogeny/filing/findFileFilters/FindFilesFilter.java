/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.findFileFilters;

import org.jetbrains.annotations.NotNull;
import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import com.softwarecraftsmen.orogeny.filing.RelativeDirectory;
import com.softwarecraftsmen.orogeny.filing.FileName;

public interface FindFilesFilter
{
	boolean include(final @NotNull AbsoluteDirectory root, final @NotNull RelativeDirectory relativeDirectory, final @NotNull FileName fileName);

	boolean exclude(final @NotNull AbsoluteDirectory root, final @NotNull RelativeDirectory relativeDirectory, final @NotNull FileName fileName);

	@NotNull
	FindFilesFilter and(final @NotNull FindFilesFilter that);

	@NotNull
	FindFilesFilter or(final @NotNull FindFilesFilter that);

	@NotNull
	FindFilesFilter not();

	@NotNull
	FindFilesFilter exclude(final @NotNull FindFilesFilter exclude);

	@NotNull
	FindFilesFilter excludeHiddenFilesAndHiddenFolders();
}
