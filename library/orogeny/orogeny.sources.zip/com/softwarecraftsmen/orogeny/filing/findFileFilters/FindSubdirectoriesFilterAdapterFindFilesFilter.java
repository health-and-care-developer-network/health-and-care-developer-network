/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.findFileFilters;

import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import com.softwarecraftsmen.orogeny.filing.FileName;
import com.softwarecraftsmen.orogeny.filing.RelativeDirectory;
import com.softwarecraftsmen.orogeny.filing.findSubdirectoriesFilters.FindSubdirectoriesFilter;
import org.jetbrains.annotations.NotNull;

public class FindSubdirectoriesFilterAdapterFindFilesFilter extends AbstractFindFilesFilter
{
	private final FindSubdirectoriesFilter findSubdirectoriesFilter;

	public FindSubdirectoriesFilterAdapterFindFilesFilter(final @NotNull FindSubdirectoriesFilter findSubdirectoriesFilter)
	{
		this.findSubdirectoriesFilter = findSubdirectoriesFilter;
	}

	public boolean include(final @NotNull AbsoluteDirectory root, final @NotNull RelativeDirectory relativeDirectory, final @NotNull FileName fileName)
	{
		return findSubdirectoriesFilter.include(root, relativeDirectory);
	}

	@NotNull
	public String toString()
	{
		return findSubdirectoriesFilter.toString();
	}
}
