/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.fileSystems;

import org.jetbrains.annotations.NotNull;

public class ZipFileSystem extends AbstractPosixLikeFileSystem
{
	@NotNull
	public static ZipFileSystem ZipFileSystemRoot = new ZipFileSystem();

	private ZipFileSystem()
	{}
}