/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.fileSystems;

import org.jetbrains.annotations.NotNull;

public abstract class AbstractPosixLikeFileSystem extends AbstractFileSystem
{
	protected AbstractPosixLikeFileSystem()
	{
		super("/", ":", "");
	}

	@Override
	protected boolean isAbsolute(final @NotNull String firstFolderDescription)
	{
		return firstFolderDescription.equals(rootFolderName());
	}

	@NotNull
	@Override
	protected FileSystem actualFileSystem(final @NotNull String firstFolderDescription)
	{
		return this;
	}
}
