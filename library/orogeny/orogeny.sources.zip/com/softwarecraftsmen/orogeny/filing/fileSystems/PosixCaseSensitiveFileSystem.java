/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.fileSystems;

import org.jetbrains.annotations.NotNull;

public class PosixCaseSensitiveFileSystem extends AbstractPosixLikeFileSystem
{
	@NotNull
	public static final PosixCaseSensitiveFileSystem PosixRoot = new PosixCaseSensitiveFileSystem();

	private PosixCaseSensitiveFileSystem()
	{}
}
