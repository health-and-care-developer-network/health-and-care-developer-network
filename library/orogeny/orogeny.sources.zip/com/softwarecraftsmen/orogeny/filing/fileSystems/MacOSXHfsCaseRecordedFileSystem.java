/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.fileSystems;

import org.jetbrains.annotations.NotNull;
import com.softwarecraftsmen.orogeny.filing.Folder;

import java.util.List;

public class MacOSXHfsCaseRecordedFileSystem extends AbstractPosixLikeFileSystem
{
	@NotNull
	public static MacOSXHfsCaseRecordedFileSystem MacOSXHfsRoot = new MacOSXHfsCaseRecordedFileSystem();

	private MacOSXHfsCaseRecordedFileSystem()
	{}

	public boolean isHidden(final @NotNull List<? extends Folder> folders, final @NotNull String fileName)
	{
		return super.isHidden(folders, fileName) || fileName.startsWith(".");
	}
}
