/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.fileSystems;

import org.jetbrains.annotations.NotNull;
import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectories;
import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import com.softwarecraftsmen.orogeny.filing.Directory;
import com.softwarecraftsmen.orogeny.filing.Folder;
import com.softwarecraftsmen.orogeny.filing.AbsoluteFile;
import com.softwarecraftsmen.orogeny.filing.Folder.OrdinaryFolder;

import java.util.List;
import java.io.File;

public interface FileSystem
{
	@NotNull
	String rootFolderName();

	@NotNull
	String folderSeparator();

	@NotNull
	String pathSeparator();

	@NotNull
	AbsoluteDirectory root();

	@NotNull
	AbsoluteDirectories toPaths(final @NotNull AbsoluteDirectory root, final @NotNull String pathsDescription);

	@NotNull
	AbsoluteDirectory toPath(final @NotNull AbsoluteDirectory root, final @NotNull String pathDescription);

	@NotNull
	Directory toPath(final @NotNull String pathDescription);

	@NotNull
	OrdinaryFolder rootFolder();

	@NotNull
	AbsoluteFile toFile(@NotNull AbsoluteDirectory root, @NotNull String pathDescription);

	@NotNull
	String toFileSystemSpecificPathPrefixedByPathSeparator(final @NotNull List<? extends Folder> folders);

	@NotNull
	String toFileSystemSpecificPathPrefixedByPathSeparator(final @NotNull List<? extends Folder> folders, final @NotNull String fileName);

	@NotNull
	String toFileSystemSpecificPathPostfixedByFolderSeparator(final @NotNull List<? extends Folder> folders);

	@NotNull
	String toFileSystemSpecificPathPostfixedByPathSeparator(final @NotNull List<? extends Folder> folders);

	@NotNull
	String toFileSystemSpecificPathPostfixedByPathSeparator(final @NotNull List<? extends Folder> folders, final @NotNull String fileName);

	@NotNull
	String toFileSystemSpecificPath(final @NotNull List<? extends Folder> folders);

	@NotNull
	String toFileSystemSpecificPath(final @NotNull List<? extends Folder> folders, final @NotNull String fileName);

	boolean isHidden(final @NotNull List<? extends Folder> folders);

	boolean isHidden(final @NotNull List<? extends Folder> folders, final @NotNull String fileName);

	boolean isRoot(final @NotNull File currentFolder);
}
