/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class CouldNotDeleteFileException extends FilingOperationFailedException
{
	public CouldNotDeleteFileException(final @NotNull AbsoluteDirectory absoluteDirectory, final @NotNull FileName fileName)
	{
		super(format(UK, "Could not delete file %1$s in path %2$s", fileName, absoluteDirectory));
	}
}
