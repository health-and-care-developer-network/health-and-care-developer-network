/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

public interface Directory
{
	@NotNull
	public AbsoluteDirectory makeAbsolute(final @NotNull AbsoluteDirectory root);
}
