/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class CouldNotDeleteFolderException extends FilingOperationFailedException
{
	public CouldNotDeleteFolderException(final @NotNull AbsoluteDirectory absoluteDirectory, final @NotNull FilingOperationFailedException cause)
	{
		super(format(UK, "Could not delete path %1$s", absoluteDirectory), cause);
	}

	public CouldNotDeleteFolderException(final @NotNull AbsoluteDirectory absoluteDirectory)
	{
		super(format(UK, "Could not delete path %1$s", absoluteDirectory));
	}
}