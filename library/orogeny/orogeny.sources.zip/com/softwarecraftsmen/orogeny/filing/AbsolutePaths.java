/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import com.softwarecraftsmen.orogeny.filing.findFileFilters.FindFilesFilter;
import com.softwarecraftsmen.orogeny.filing.findSubdirectoriesFilters.FindSubdirectoriesFilter;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.Set;

public interface AbsolutePaths
{
	@NotNull
	AbsolutePaths and(final @NotNull AbsolutePath absolutePath);

	@NotNull
	AbsolutePaths and(final @NotNull AbsolutePaths absolutePaths);

	@NotNull
	String toFileSystemSpecificPath();

	boolean exists();

	@NotNull
	Set<File> toFiles();

	@NotNull
	Set<AbsoluteFile> findFiles(final @NotNull FindFilesFilter findFilesFilter);

	@NotNull
	Set<AbsoluteDirectory> findSubdirectories(final @NotNull FindSubdirectoriesFilter findSubdirectoriesFilter);

	@NotNull
	Set<AbsoluteFile> files();

	@NotNull
	Set<AbsoluteDirectory> directories();

	boolean isEmpty();
}
