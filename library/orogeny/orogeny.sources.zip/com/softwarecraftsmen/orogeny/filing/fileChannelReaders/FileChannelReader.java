/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.fileChannelReaders;

import org.jetbrains.annotations.NotNull;

import java.nio.channels.FileChannel;
import java.io.IOException;

public interface FileChannelReader<T>
{
	@NotNull
	T read(final @NotNull FileChannel readableFileChannel) throws IOException;
}
