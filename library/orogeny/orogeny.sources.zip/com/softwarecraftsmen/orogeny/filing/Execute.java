/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

public interface Execute
{
	void setExecutable(final @NotNull ProcessBuilder processBuilder);

	boolean isExecutable();
}
