/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class IsNotADirectoryException extends FilingOperationFailedException
{
	public IsNotADirectoryException(final @NotNull AbsoluteDirectory directory)
	{
		super(format(UK, "The directory %1$s is not a directory and can not be deleted", directory));
	}
}
