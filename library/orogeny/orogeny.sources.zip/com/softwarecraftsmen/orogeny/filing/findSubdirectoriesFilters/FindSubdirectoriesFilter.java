/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.findSubdirectoriesFilters;

import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import com.softwarecraftsmen.orogeny.filing.RelativeDirectory;
import org.jetbrains.annotations.NotNull;

public interface FindSubdirectoriesFilter
{
	boolean include(final @NotNull AbsoluteDirectory root, final @NotNull RelativeDirectory relativeDirectory);

	boolean exclude(final @NotNull AbsoluteDirectory root, final @NotNull RelativeDirectory relativeDirectory);

	@NotNull
	FindSubdirectoriesFilter and(final @NotNull FindSubdirectoriesFilter that);

	@NotNull
	FindSubdirectoriesFilter or(final @NotNull FindSubdirectoriesFilter that);

	@NotNull
	FindSubdirectoriesFilter not();

	@NotNull
	FindSubdirectoriesFilter exclude(final @NotNull FindSubdirectoriesFilter exclude);

	@NotNull
	FindSubdirectoriesFilter excludeHiddenFolders();
}
