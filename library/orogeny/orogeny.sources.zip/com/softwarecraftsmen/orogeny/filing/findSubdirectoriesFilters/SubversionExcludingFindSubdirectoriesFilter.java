/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.findSubdirectoriesFilters;

import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import static com.softwarecraftsmen.orogeny.filing.Folder.Ordinary;
import com.softwarecraftsmen.orogeny.filing.Folder.OrdinaryFolder;
import com.softwarecraftsmen.orogeny.filing.RelativeDirectory;
import org.jetbrains.annotations.NotNull;

public final class SubversionExcludingFindSubdirectoriesFilter extends AbstractFindSubdirectoriesFilter
{
	@NotNull
	public static final AbstractFindSubdirectoriesFilter SubversionExcluding = new SubversionExcludingFindSubdirectoriesFilter();
	private static final OrdinaryFolder SubversionFolder = Ordinary(".svn");

	public boolean include(final @NotNull AbsoluteDirectory root, final @NotNull RelativeDirectory relativeDirectory)
	{
		return !relativeDirectory.makeAbsolute(root).deepestFolder().equals(SubversionFolder);
	}

	@NotNull
	public String toString()
	{
		return "SubversionExcluding";
	}

	private SubversionExcludingFindSubdirectoriesFilter()
	{}
}