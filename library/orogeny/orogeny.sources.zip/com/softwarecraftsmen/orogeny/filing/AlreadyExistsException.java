/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import java.util.Locale;

public class AlreadyExistsException extends FilingOperationFailedException
{
	public AlreadyExistsException(final AbsoluteFile that)
	{
		super(String.format(Locale.UK, "%1$s is a file and already exists", that));
	}
}
