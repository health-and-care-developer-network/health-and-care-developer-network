/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

import java.util.Locale;

public class IsNotAFileException extends FilingOperationFailedException
{
	public IsNotAFileException(final @NotNull AbsoluteDirectory absoluteDirectory, final @NotNull FileName fileName)
	{
		super(String.format(Locale.UK, "The path %1$s does not have a file called %2$s in it but a folder", absoluteDirectory, fileName));
	}
}
