/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class CouldNotMakeAllFoldersNecessaryException extends FilingOperationFailedException
{
	public CouldNotMakeAllFoldersNecessaryException(final @NotNull AbsoluteDirectory absoluteDirectory)
	{
		super(format(UK, "Could not make all the folders necessary to create %1$s", absoluteDirectory));
	}
}
