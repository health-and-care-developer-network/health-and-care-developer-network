/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class NotAZipFileException extends FilingOperationFailedException
{
	public NotAZipFileException(final @NotNull AbsoluteFile file)
	{
		super(format(UK, "The file %1$s could not be opened as a zip (or jar) file", file));
	}

}
