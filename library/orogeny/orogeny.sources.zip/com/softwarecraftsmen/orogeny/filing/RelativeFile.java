/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import static com.softwarecraftsmen.orogeny.filing.fileSystems.AbstractFileSystem.CurrentFileSystem;
import com.softwarecraftsmen.orogeny.filing.fileSystems.FileSystem;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class RelativeFile
{
	private final RelativeDirectory relativeDirectory;
	private final FileName fileName;

	public RelativeFile(final @NotNull RelativeDirectory relativeDirectory, final @NotNull FileName fileName)
	{
		this.relativeDirectory = relativeDirectory;
		this.fileName = fileName;
	}

	@NotNull
	public String toString()
	{
		return toFileSystemSpecificPath(CurrentFileSystem);
	}

	public boolean equals(final @Nullable Object o)
	{
		if (this == o)
		{
			return true;
		}
		if (o == null || getClass() != o.getClass())
		{
			return false;
		}

		final RelativeFile that = (RelativeFile) o;
		return fileName.equals(that.fileName) && relativeDirectory.equals(that.relativeDirectory);
	}

	public int hashCode()
	{
		int result;
		result = relativeDirectory.hashCode();
		result = 31 * result + fileName.hashCode();
		return result;
	}

	@NotNull
	public String toFileSystemSpecificPath(final @NotNull FileSystem fileSystem)
	{
		return fileName.toFileSystemSpecificPath(fileSystem, relativeDirectory);
	}

	@NotNull
	public AbsoluteFile makeAbsolute(final @NotNull AbsoluteDirectory absoluteDirectory)
	{
		return relativeDirectory.makeAbsolute(absoluteDirectory).file(fileName);
	}
}
