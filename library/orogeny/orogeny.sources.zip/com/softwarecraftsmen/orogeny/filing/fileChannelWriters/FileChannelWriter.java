/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing.fileChannelWriters;

import org.jetbrains.annotations.NotNull;

import java.nio.channels.FileChannel;
import java.io.IOException;

public interface FileChannelWriter
{
	void write(final @NotNull FileChannel writableFileChannel) throws IOException;
}
