/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

public abstract class FilingOperationFailedException extends RuntimeException
{
	protected FilingOperationFailedException(final @NotNull String message)
	{
		super(message);
	}

	public FilingOperationFailedException(final @NotNull String message, final @NotNull FilingOperationFailedException cause)
	{
		super(message, cause);
	}

	public FilingOperationFailedException(final @NotNull String message, final @NotNull IOException cause)
	{
		super(message, cause);
	}
}
