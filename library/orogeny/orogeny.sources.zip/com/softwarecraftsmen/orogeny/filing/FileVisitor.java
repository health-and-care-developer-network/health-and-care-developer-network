/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.filing;

import org.jetbrains.annotations.NotNull;

public interface FileVisitor
{
	void visitFile(final @NotNull AbsoluteDirectory root, final @NotNull FileName fileName);
}
