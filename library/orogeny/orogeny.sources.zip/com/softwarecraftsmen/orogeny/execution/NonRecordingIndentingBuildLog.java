/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.execution;

import org.jetbrains.annotations.NotNull;
import com.softwarecraftsmen.orogeny.buildLogs.IndentingBuildLog;
import com.softwarecraftsmen.orogeny.buildLogs.Indentation;
import com.softwarecraftsmen.orogeny.buildLogs.Verbosity;

public class NonRecordingIndentingBuildLog implements RecordingBuildLog
{
	private final IndentingBuildLog indentingBuildLog;

	public NonRecordingIndentingBuildLog(final @NotNull IndentingBuildLog indentingBuildLog)
	{
		this.indentingBuildLog = indentingBuildLog;
	}

	public void writeMessage(@NotNull final IndentingBuildLog indentingBuildLog)
	{
	}

	public void writeMessage(final @NotNull Indentation indentation, final @NotNull String message)
	{
		indentingBuildLog.writeMessage(indentation, message);
	}

	public void writeMessage(final @NotNull Indentation indentation, final @NotNull SuccessOrFailure successOrFailure)
	{
		indentingBuildLog.writeMessage(indentation, successOrFailure);
	}

	public void writeMessage(final @NotNull Verbosity verbosity, final @NotNull String message)
	{
		indentingBuildLog.writeMessage(verbosity, message);
	}
}
