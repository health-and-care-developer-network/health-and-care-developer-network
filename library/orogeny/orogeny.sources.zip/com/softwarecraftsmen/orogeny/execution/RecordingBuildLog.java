/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.execution;

import org.jetbrains.annotations.NotNull;
import com.softwarecraftsmen.orogeny.buildLogs.IndentingBuildLog;

public interface RecordingBuildLog extends IndentingBuildLog
{
	void writeMessage(@NotNull IndentingBuildLog indentingBuildLog);
}
