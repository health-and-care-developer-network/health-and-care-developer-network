/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.execution;

import com.softwarecraftsmen.orogeny.taskNames.TaskName;
import com.softwarecraftsmen.orogeny.buildLogs.IndentingBuildLog;
import static com.softwarecraftsmen.orogeny.buildLogs.Indentation.TaskIndentation;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.Set;

public class TaskCompletionNotification
{
	@NotNull
	private final TaskName taskName;

	@NotNull
	private final SuccessOrFailure successOrFailure;
	private final RecordingBuildLog recordingBuildLog;

	public TaskCompletionNotification(final @NotNull TaskName taskName, final @NotNull SuccessOrFailure successOrFailure, final @NotNull RecordingBuildLog recordingBuildLog)
	{
		this.taskName = taskName;
		this.successOrFailure = successOrFailure;
		this.recordingBuildLog = recordingBuildLog;
	}

	public void removeFrom(final @NotNull Map<TaskName, ?> taskNameMap)
	{
		taskNameMap.remove(taskName);
	}

	public void addTo(final @NotNull Set<TaskName> taskNames)
	{
		taskNames.add(taskName);
	}

	public boolean isFailure()
	{
		return successOrFailure.isFailure();
	}

	@NotNull
	public SuccessOrFailure successOrFailure()
	{
		return successOrFailure;
	}

	public void writeMessage(final @NotNull IndentingBuildLog indentingBuildLog)
	{
		indentingBuildLog.writeMessage(TaskIndentation, taskName.toString());
		recordingBuildLog.writeMessage(indentingBuildLog);
		indentingBuildLog.writeMessage(TaskIndentation, successOrFailure);
	}
}
