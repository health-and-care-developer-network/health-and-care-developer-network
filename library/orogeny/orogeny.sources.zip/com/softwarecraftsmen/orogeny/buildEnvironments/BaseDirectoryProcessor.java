/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.buildEnvironments;

import com.softwarecraftsmen.orogeny.BaseDirectory;
import com.softwarecraftsmen.orogeny.BuildScript;
import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import static com.softwarecraftsmen.orogeny.filing.fileSystems.AbstractFileSystem.CurrentFileSystem;
import org.jetbrains.annotations.NotNull;

public class BaseDirectoryProcessor
{
	private final Class<? extends BuildScript> buildScript;

	public BaseDirectoryProcessor(final @NotNull Class<? extends BuildScript> buildScript)
	{
		this.buildScript = buildScript;
	}

	// TODO: Specify file system to interpet with...
	@NotNull
	public AbsoluteDirectory currentBuildDirectory(final @NotNull AbsoluteDirectory originalBuildDirectory)
	{
		return CurrentFileSystem.toPath(originalBuildDirectory, getBuildDirectoryPathModification());
	}

	// This is an offset or absolute path to the location of the build script
	private String getBuildDirectoryPathModification()
	{
		final BaseDirectory annotation = buildScript.getAnnotation(BaseDirectory.class);
		if (annotation != null)
		{
			return annotation.value();
		}
		return ".";
	}
}
