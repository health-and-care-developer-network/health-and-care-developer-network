/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.buildEnvironments;

import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import static com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory.absoluteDirectory;
import static com.softwarecraftsmen.orogeny.filing.fileSystems.AbstractFileSystem.CurrentFileSystem;
import org.jetbrains.annotations.NotNull;

import java.io.File;

public class BuildDirectoryFinder
{
	private final BaseDirectoryProcessor baseDirectoryProcessor;

	public BuildDirectoryFinder(final @NotNull BaseDirectoryProcessor baseDirectoryProcessor)
	{
		this.baseDirectoryProcessor = baseDirectoryProcessor;
	}

	@NotNull
	public AbsoluteDirectory currentBuildDirectory(final @NotNull File scriptFileParentFolder)
	{
		final AbsoluteDirectory originalBuildDirectory = absoluteDirectory(CurrentFileSystem, scriptFileParentFolder);
		return baseDirectoryProcessor.currentBuildDirectory(originalBuildDirectory);
	}
}
