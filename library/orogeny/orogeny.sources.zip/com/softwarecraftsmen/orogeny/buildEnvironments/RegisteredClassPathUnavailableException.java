/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.buildEnvironments;

import com.softwarecraftsmen.orogeny.BuildScript.BuildSyntaxException;
import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public final class RegisteredClassPathUnavailableException extends BuildSyntaxException
{
	public RegisteredClassPathUnavailableException(final @NotNull String name)
	{
		super(format(UK, "Registered class path %1$s is unavailable. It may not yet have been registered", name));
	}
}
