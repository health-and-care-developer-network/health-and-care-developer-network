/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.buildEnvironments;

import com.softwarecraftsmen.orogeny.filing.AbsolutePath;
import org.jetbrains.annotations.NotNull;

public interface BuildDateTime
{
	@NotNull
	String iso8601Date();

	@NotNull
	String dailyBuildLabel();

	@NotNull
	String interDayBuildLabel(@NotNull String variant);

	@NotNull
	String byTheSecondBuildLabel();

	@NotNull
	String year();

	@NotNull
	String yearMonth(@NotNull String dateSeparator);

	@NotNull
	String yearMonthDay(@NotNull String dateSeparator);

	@NotNull
	String hour();

	@NotNull
	String hourMinute(@NotNull String timeSeparator);

	@NotNull
	String hourMinuteSecond(@NotNull String timeSeparator);

	@NotNull
	String hourMinuteSecondMillisecond(@NotNull String timeSeparator, @NotNull String millisecondSeparator);

	@NotNull
	String yearMonthDayHourMinuteSecond(@NotNull String dateSeparator, @NotNull String dateToTimeSeparator, @NotNull String timeSeparator);

	@NotNull
	String yearMonthDayHourMinuteSecondMillisecond(@NotNull String dateSeparator, @NotNull String dateToTimeSeparator, @NotNull String timeSeparator, @NotNull String millisecondSeparator);

	void touch(final @NotNull AbsolutePath absolutePath);
}
