/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.orogeny.buildEnvironments;

import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectory;
import com.softwarecraftsmen.orogeny.filing.AbsolutePaths;
import com.softwarecraftsmen.orogeny.filing.fileSystems.FileSystem;
import com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystem;
import com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystemFamily;
import com.softwarecraftsmen.orogeny.operatingSystems.OperatingSystemPlatform;
import com.softwarecraftsmen.orogeny.properties.Evaluatable;
import com.softwarecraftsmen.orogeny.properties.PropertyName;
import org.jetbrains.annotations.NotNull;

import java.util.SortedSet;
import java.util.UUID;

// TODO: Consider adding a "buildLabel" to the environment with a labelling strategy in an enumeration?
public interface BuildEnvironment
{
	@NotNull
	String currentBuildName();

	@NotNull
	UUID currentBuildUuid();

	@NotNull
	BuildDateTime currentBuildDateTime();

	@NotNull
	OperatingSystem currentOperatingSystem();

	@NotNull
	OperatingSystemPlatform currentOperatingSystemPlatform();

	@NotNull
	OperatingSystemFamily currentOperatingSystemFamily();

	@NotNull
	FileSystem currentFileSystem();

	@NotNull
	AbsoluteDirectory currentWorkingDirectory();

	@NotNull
	AbsoluteDirectory currentUserHomeDirectory();

	@NotNull
	AbsoluteDirectory currentBuildDirectory();

	@NotNull
	AbsolutePaths registeredPaths(final @NotNull String name) throws RegisteredClassPathUnavailableException;

	@NotNull
	Evaluatable getProperty(final @NotNull PropertyName propertyName);

	void putProperty(final @NotNull PropertyName propertyName, final @NotNull Evaluatable evaluatable);

	@NotNull
	SortedSet<PropertyName> allPropertyNames();

	void registerPaths(final @NotNull String name, final @NotNull AbsolutePaths classPath);

}
