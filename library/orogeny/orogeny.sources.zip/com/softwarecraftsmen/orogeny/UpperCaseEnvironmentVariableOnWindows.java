/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */

// TODO: Implement so that PATH, etc are forced into uppercase on Windows

package com.softwarecraftsmen.orogeny;

import org.jetbrains.annotations.NotNull;

import static java.lang.annotation.ElementType.TYPE;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import java.lang.annotation.Target;

/**
 * All environment variables found whose uppercase form matches one of the values specified will have their case modified
 */
@Target(TYPE)
@Retention(RUNTIME)
@Inherited
public @interface UpperCaseEnvironmentVariableOnWindows
{
	@NotNull public abstract String[] value();
}
