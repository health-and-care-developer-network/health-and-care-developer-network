/**
 * This file is Copyright © 2009 Vubble Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.posix;

import org.jetbrains.annotations.Nullable;

public interface ErrorHandler
{
	void handleError(final @Nullable String extraData);
}
