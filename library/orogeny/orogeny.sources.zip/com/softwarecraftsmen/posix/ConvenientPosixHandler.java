package com.softwarecraftsmen.posix;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jruby.ext.posix.POSIX;
import static org.jruby.ext.posix.POSIXFactory.getPOSIX;
import org.jruby.ext.posix.POSIXHandler;
import org.jruby.ext.posix.POSIX.ERRORS;

import java.io.File;
import java.io.InputStream;
import java.io.PrintStream;
import static java.lang.String.format;
import static java.lang.System.*;
import static java.util.Locale.UK;

/**
 * This file is Copyright © 2009 Vubble Limited. All Rights Reserved.
 */
public class ConvenientPosixHandler implements POSIXHandler
{
	@NotNull
	public static final POSIX posix = getPosix(new ConvenientPosixHandler());

	@NotNull
	public static POSIX posixWithEnoentErrorHandler(final @NotNull ErrorHandler enoentErrorHandler)
	{
		return getPOSIX(new ConvenientPosixHandler()
		{
			public void error(@NotNull final ERRORS error, final @Nullable String extraData)
			{
				if (error == ERRORS.ENOENT)
				{
					enoentErrorHandler.handleError(extraData);
				}
			}
		}, true);
	}

	@NotNull
	private static POSIX getPosix(final @NotNull POSIXHandler posixHandler)
	{
		return getPOSIX(posixHandler, true);
	}

	private static final File CurrentWorkingDirectory = new File(getProperty("user.dir", "/"));

	private ConvenientPosixHandler()
	{
	}

	public void error(final @NotNull POSIX.ERRORS error, final @Nullable String extraData)
	{
		throw new IllegalStateException(format(UK, "POSIX error name '%1$s', with extra information '%2$s'", error, extraData));
	}

	public void unimplementedError(final @NotNull String methodName)
	{
		throw new UnsupportedOperationException(format(UK, "The POSIX method '%1$s' is not implemented", methodName));
	}

	public void warn(final WARNING_ID id, final String message, final Object... data)
	{
		throw new UnsupportedOperationException("Use of this method implies the pure Java POSIX emulation is in use");
	}

	public boolean isVerbose()
	{
		return false;
	}

	@NotNull
	public File getCurrentWorkingDirectory()
	{
		return CurrentWorkingDirectory;
	}

	// Used by exec(); null makes it inherit from the current process
	@Nullable
	public String[] getEnv()
	{
		return null;
	}

	@NotNull
	public InputStream getInputStream()
	{
		return in;
	}

	@NotNull
	public PrintStream getOutputStream()
	{
		return out;
	}

	public int getPID()
	{
		throw new UnsupportedOperationException("Use of this method implies the pure Java POSIX emulation is in use");
	}

	@NotNull
	public PrintStream getErrorStream()
	{
		return err;
	}
}
