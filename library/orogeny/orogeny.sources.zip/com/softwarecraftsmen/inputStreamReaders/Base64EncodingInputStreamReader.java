/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.inputStreamReaders;

import com.softwarecraftsmen.encoding.base64.Base64Encoder;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.BufferedInputStream;

public class Base64EncodingInputStreamReader implements InputStreamReader<String>
{
	private static final Base64Encoder encoder = new Base64Encoder();
	private final InputStreamReader<byte[]> inputStreamReader;

	public Base64EncodingInputStreamReader(final @NotNull InputStreamReader<byte[]> inputStreamReader)
	{
		this.inputStreamReader = inputStreamReader;
	}

	@NotNull
	public String read(final int inputBufferSize, final @NotNull BufferedInputStream inputStream) throws IOException
	{
		return encoder.encode(inputStreamReader.read(inputBufferSize, inputStream));
	}
}
