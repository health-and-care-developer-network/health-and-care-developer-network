/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.inputStreamReaders;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.BufferedInputStream;
import java.security.MessageDigest;

public class Sha1DigestComputingInputStreamReader implements InputStreamReader<byte[]>
{
	@NotNull
	public byte[] read(final int inputBufferSize, final @NotNull BufferedInputStream inputStream) throws IOException
	{
		final MessageDigest sha1MessageDigest = Sha1MessageDigest.newSha1Digest();

		final byte[] buffer = new byte[inputBufferSize];
		int bytesRead;
		while ((bytesRead = inputStream.read(buffer)) != -1)
		{
			sha1MessageDigest.update(buffer, 0, bytesRead);
		}
		return sha1MessageDigest.digest();
	}
}
