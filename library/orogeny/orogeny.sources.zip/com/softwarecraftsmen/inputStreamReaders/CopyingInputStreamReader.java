/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.inputStreamReaders;

import com.softwarecraftsmen.inputStreamReaders.InputStreamReader.Nothing;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.OutputStream;
import java.io.BufferedInputStream;

public class CopyingInputStreamReader implements InputStreamReader<Nothing>
{
	private final OutputStream outputStream;

	public CopyingInputStreamReader(final @NotNull OutputStream outputStream)
	{
		this.outputStream = outputStream;
	}

	@NotNull
	public Nothing read(final int inputBufferSize, final @NotNull BufferedInputStream inputStream) throws IOException
	{
		final byte[] buffer = new byte[inputBufferSize];
		int bytesRead;
		while ((bytesRead = inputStream.read(buffer)) != -1)
		{
			outputStream.write(buffer, 0, bytesRead);
		}
		return Nothing;
	}
}
