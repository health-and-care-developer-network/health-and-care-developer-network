/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.inputStreamReaders;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

public interface ReadableData
{
	@NotNull
	<T> T readData(final @NotNull InputStreamReader<T> inputStreamReader) throws IOException;
}
