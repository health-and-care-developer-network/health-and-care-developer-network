/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.inputStreamReaders;

import org.jetbrains.annotations.NotNull;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import static java.security.MessageDigest.getInstance;

public final class Sha1MessageDigest
{
	private Sha1MessageDigest()
	{}

	@NotNull
	public static MessageDigest newSha1Digest()
	{
		try
		{
			return getInstance("SHA1");
		}
		catch (NoSuchAlgorithmException e)
		{
			throw new IllegalStateException("There is no SHA1 message digest algorithm. Your Java installation is unusual or broken.", e);
		}
	}
}
