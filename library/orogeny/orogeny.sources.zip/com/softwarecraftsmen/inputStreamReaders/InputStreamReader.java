/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.inputStreamReaders;

import org.jetbrains.annotations.NotNull;

import java.io.BufferedInputStream;
import java.io.IOException;

public interface InputStreamReader<T>
{
	@NotNull
	T read(final int inputBufferSize, final @NotNull BufferedInputStream inputStream) throws IOException;

	@NotNull
	public static final Nothing Nothing = new Nothing();

	public static final class Nothing
	{
		private Nothing()
		{}
	}
}
