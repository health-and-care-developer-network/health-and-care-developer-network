/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.inputStreamReaders;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.BufferedInputStream;
import java.util.jar.Manifest;

public class ManifestInputStreamReader implements InputStreamReader<Manifest>
{
	@NotNull
	public Manifest read(final int inputBufferSize, final @NotNull BufferedInputStream inputStream) throws IOException
	{
		return new Manifest(inputStream);
	}
}
