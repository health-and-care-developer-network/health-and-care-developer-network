/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.compressors;

import org.jetbrains.annotations.NotNull;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

public interface Compressor
{
	void compress(final @NotNull InputStream inputStream, final @NotNull OutputStream outputStream) throws IOException;
}
