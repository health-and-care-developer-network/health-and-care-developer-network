/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.compressors;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;
import static java.util.zip.Deflater.BEST_COMPRESSION;

public class ZlibCompressor implements Compressor
{
	private ZlibCompressor()
	{}

	@NotNull
	public static Compressor ZLib = new ZlibCompressor();

	private static final int OneKilobyte = 1024;
	private static final int BufferSize = 8 * OneKilobyte;

	public void compress(final @NotNull InputStream inputStream, final @NotNull OutputStream outputStream) throws IOException
	{
		final DeflaterOutputStream deflaterOutputStream = new DeflaterOutputStream(outputStream, new Deflater(BEST_COMPRESSION, false),  BufferSize);
		try
		{
			final byte[] buffer = new byte[BufferSize];
			int bytesRead;
			while((bytesRead = inputStream.read(buffer)) != -1)
			{
				deflaterOutputStream.write(buffer, 0, bytesRead);
			}
		}
		finally
		{
			deflaterOutputStream.finish();
		}
	}
}