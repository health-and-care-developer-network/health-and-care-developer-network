/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.compressors;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

public class GzipCompressor implements Compressor
{
	private GzipCompressor()
	{}

	@NotNull
	public static Compressor GZip = new GzipCompressor();

	private static final int OneKilobyte = 1024;
	private static final int BufferSize = 8 * OneKilobyte;

	public void compress(final @NotNull InputStream inputStream, final @NotNull OutputStream outputStream) throws IOException
	{
		final GZIPOutputStream gzipOutputStream = new GZIPOutputStream(outputStream, BufferSize);
		try
		{
			final byte[] buffer = new byte[BufferSize];
			int bytesRead;
			while((bytesRead = inputStream.read(buffer)) != -1)
			{
				gzipOutputStream.write(buffer, 0, bytesRead);
			}
		}
		finally
		{
			gzipOutputStream.finish();
		}
	}
}
