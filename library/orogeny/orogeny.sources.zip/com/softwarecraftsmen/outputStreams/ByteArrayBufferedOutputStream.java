/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.outputStreams;

import com.softwarecraftsmen.outputStreamWriters.OutputStreamWriter;
import com.softwarecraftsmen.outputStreamWriters.WritableData;
import org.jetbrains.annotations.NotNull;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ByteArrayBufferedOutputStream extends BufferedOutputStream implements WritableData
{
	public static final int MinimumOutputBufferSize = 0;
	@NotNull
	public static final ByteArrayBufferedOutputStream EmptyBufferedByteArrayOutputStream = new ByteArrayBufferedOutputStream(MinimumOutputBufferSize);
	private final int bufferSize;

	public ByteArrayBufferedOutputStream(final int bufferSize)
	{
		super(new ByteArrayOutputStream(bufferSize), 1);
		this.bufferSize = bufferSize;
	}

	public void writeData(final @NotNull OutputStreamWriter outputStreamWriter)
	{
		try
		{
			outputStreamWriter.write(bufferSize, this);
		}
		catch (IOException e)
		{
			throw new IllegalStateException("Should never happen", e);
		}
	}

	@NotNull
	public byte[] toByteArray()
	{
		return ((ByteArrayOutputStream) super.out).toByteArray();
	}
}
