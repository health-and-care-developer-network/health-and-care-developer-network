/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.archivers.tar.fileEntries;

import com.softwarecraftsmen.archivers.tar.fileEntries.headers.FileHeaderWriter;
import static com.softwarecraftsmen.archivers.tar.fileEntries.headers.FileHeaderWriter.EmptyLinkName;
import static com.softwarecraftsmen.archivers.tar.fileEntries.headers.LinkFlag.Directory;
import com.softwarecraftsmen.inputStreamReaders.InputStreamReader;
import static com.softwarecraftsmen.inputStreams.ByteArrayBufferedInputStream.EmptyBufferedByteArrayInputStream;
import com.softwarecraftsmen.orogeny.filing.RelativeDirectory;
import com.softwarecraftsmen.orogeny.filing.absolutePathMetaData.AbsolutePathMetaData;
import static com.softwarecraftsmen.orogeny.filing.fileSystems.PosixCaseSensitiveFileSystem.PosixRoot;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import static java.lang.String.format;
import static java.util.Locale.UK;

public class DirectoryFileEntry implements FileEntry
{
	private final AbsolutePathMetaData directoryMetaData;
	private final String directoryName;

	public DirectoryFileEntry(final @NotNull RelativeDirectory directoryInTar, final boolean makeAbsolute, final @NotNull AbsolutePathMetaData directoryMetaData)
	{
		this.directoryMetaData = directoryMetaData;
		directoryName = makeAbsolute ? directoryInTar.makeAbsolute(PosixRoot.root()).toFileSystemSpecificPathPostfixedByFolderSeparator() : directoryInTar.toFileSystemSpecificPathPostfixedByFolderSeparator(PosixRoot);
	}

	@NotNull
	public <T> T readData(final @NotNull InputStreamReader<T> inputStreamReader) throws IOException
	{
		return EmptyBufferedByteArrayInputStream.readData(inputStreamReader);
	}

	public void writeFileHeader(@NotNull final FileHeaderWriter fileHeaderWriter)
	{
		fileHeaderWriter.writeHeader(directoryName, directoryMetaData, Directory, EmptyLinkName);
	}

	@NotNull
	public String toString()
	{
		return format(UK, "DirectoryFileEntry(%1$s)", directoryName);
	}
}