/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.archivers.tar.fileEntries;

import com.softwarecraftsmen.inputStreamReaders.ReadableData;
import com.softwarecraftsmen.archivers.tar.fileEntries.headers.FileHeaderWriter;
import org.jetbrains.annotations.NotNull;

public interface FileEntry extends ReadableData
{
	void writeFileHeader(final @NotNull FileHeaderWriter fileHeaderWriter);
}
