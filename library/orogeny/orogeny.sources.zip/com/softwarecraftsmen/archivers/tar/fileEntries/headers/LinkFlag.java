/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.archivers.tar.fileEntries.headers;

public enum LinkFlag
{
	OldNormalFile((byte)0),
	NormalFile('0'),
	HardLink('1'),
	SymbolicLink('2'),
	CharacterDevice('3'),
	BlockDevice('4'),
	Directory('5'),
	FIFO('6'),
	Config('7');

	private final byte value;
	private static final int offsetToLinkFlag = 156;

	private LinkFlag(final byte value)
	{
		this.value = value;
	}

	private LinkFlag(final char value)
	{
		this((byte)value);
	}

	public void write(final byte[] headerBlock)
	{
		headerBlock[offsetToLinkFlag] = value;
	}
}
