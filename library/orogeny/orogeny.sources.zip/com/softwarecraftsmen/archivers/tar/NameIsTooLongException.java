/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.archivers.tar;

import org.jetbrains.annotations.NotNull;

import static java.lang.String.format;
import static java.util.Locale.UK;

public class NameIsTooLongException extends IllegalArgumentException
{
	public NameIsTooLongException(final @NotNull String name, final int maximumLength)
	{
		super(format(UK, "The maximum name length permitted is %1$s. %2$s's length is %3$s.", maximumLength, name, name.length()));
	}
}