/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.archivers.none;

import com.softwarecraftsmen.archivers.Archiver;
import com.softwarecraftsmen.orogeny.filing.AbsoluteDirectories;
import com.softwarecraftsmen.orogeny.filing.AbsoluteFile;
import com.softwarecraftsmen.orogeny.filing.findFileFilters.FindFilesFilter;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;

public class NoneArchiver implements Archiver
{
	private NoneArchiver()
	{}

	@NotNull
	public static NoneArchiver NoneArchiver = new NoneArchiver();

	public void archive(final @NotNull AbsoluteFile archiveFile, final @NotNull AbsoluteDirectories archiveRoots, final @NotNull FindFilesFilter includeFiles) throws IOException
	{
	}

	@NotNull
	public String toString()
	{
		return "NoneArchiver";
	}
}
