/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.archivers.zip.zipEntryAndData;

import com.softwarecraftsmen.inputStreamReaders.ReadableData;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.zip.ZipOutputStream;

public interface ZipEntryAndData extends ReadableData
{
	void write(final @NotNull ZipOutputStream outputStream) throws IOException;

	@NotNull
	String pathNameInsideZip();
}
