/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.archivers.zip.zipEntryAndData;

import org.jetbrains.annotations.NotNull;

import java.util.zip.ZipEntry;

public class ConvenientZipEntry extends ZipEntry
{
	public ConvenientZipEntry(final @NotNull String fileName, final long modificationTimeInMillisecondsSinceEpoch)
	{
		super(fileName);
		setComment("Added by Orogeny");
		setMethod(DEFLATED);
		setTime(modificationTimeInMillisecondsSinceEpoch);
	}
}
