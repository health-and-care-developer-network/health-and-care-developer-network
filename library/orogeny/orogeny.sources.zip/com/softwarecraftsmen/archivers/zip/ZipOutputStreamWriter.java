/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.archivers.zip;

import com.softwarecraftsmen.archivers.zip.zipEntryAndData.ZipEntryAndData;
import com.softwarecraftsmen.outputStreamWriters.OutputStreamWriter;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.BufferedOutputStream;
import java.util.Iterator;
import java.util.zip.ZipOutputStream;

public class ZipOutputStreamWriter implements OutputStreamWriter
{
	private final Iterator<ZipEntryAndData> zipEntries;

	public ZipOutputStreamWriter(final @NotNull Iterator<ZipEntryAndData> zipEntries)
	{
		this.zipEntries = zipEntries;
	}

	public void write(final int outputBufferSize, final @NotNull BufferedOutputStream outputStream) throws IOException
	{
		final ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream)
		{{
			setComment("Created by Orogeny");
			setLevel(5);
			setMethod(DEFLATED);
		}};
		while(zipEntries.hasNext())
		{
			zipEntries.next().write(zipOutputStream);
		}
		zipOutputStream.close();
	}
}
