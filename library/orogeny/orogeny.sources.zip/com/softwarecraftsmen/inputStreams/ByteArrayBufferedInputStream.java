/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.inputStreams;

import com.softwarecraftsmen.inputStreamReaders.ReadableData;
import com.softwarecraftsmen.inputStreamReaders.InputStreamReader;
import org.jetbrains.annotations.NotNull;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;

public class ByteArrayBufferedInputStream extends BufferedInputStream implements ReadableData
{
	@NotNull
	public static final ByteArrayBufferedInputStream EmptyBufferedByteArrayInputStream = new ByteArrayBufferedInputStream(new byte[]{});
	private final int actualBufferSize;

	public ByteArrayBufferedInputStream(final @NotNull byte[] data)
	{
		super(new ByteArrayInputStream(data), 1);
		actualBufferSize = data.length;
	}

	@NotNull
	public <T> T readData(final @NotNull InputStreamReader<T> inputStreamReader)
	{
		try
		{
			return inputStreamReader.read(actualBufferSize, this);
		}
		catch (IOException e)
		{
			throw new IllegalStateException("Should never happen", e);
		}
	}
}
