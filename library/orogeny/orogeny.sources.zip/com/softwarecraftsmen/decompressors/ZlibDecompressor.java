/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.decompressors;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

public class ZlibDecompressor implements Decompressor
{
	private ZlibDecompressor()
	{}

	@NotNull
	public static Decompressor ZLib = new ZlibDecompressor();

	private static final int OneKilobyte = 1024;
	private static final int BufferSize = 8 * OneKilobyte;

	public void decompress(final @NotNull InputStream inputStream, final @NotNull OutputStream outputStream) throws IOException
	{
		final InflaterInputStream inflaterInputStream = new InflaterInputStream(inputStream, new Inflater(false), BufferSize);
		final byte[] buffer = new byte[BufferSize];
		int bytesRead;
		while ((bytesRead = inflaterInputStream.read(buffer)) != -1)
		{
			outputStream.write(buffer, 0, bytesRead);
		}
	}
}