/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.decompressors.store;

import com.softwarecraftsmen.inputStreamReaders.CopyingInputStreamReader;
import com.softwarecraftsmen.decompressors.Decompressor;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedInputStream;

public final class StoreDecompressor implements Decompressor
{
	private StoreDecompressor()
	{}

	@NotNull
	public static Decompressor Store = new StoreDecompressor();

	private static final int OneKilobyte = 1024;
	private static final int BufferSize = 8 * OneKilobyte;

	public void decompress(final @NotNull InputStream inputStream, final @NotNull OutputStream outputStream) throws IOException
	{
		new CopyingInputStreamReader(outputStream).read(BufferSize, new BufferedInputStream(inputStream, BufferSize));
	}
}
