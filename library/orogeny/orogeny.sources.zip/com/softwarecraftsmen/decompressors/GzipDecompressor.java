/**
 * This file is Copyright © 2008 Software Craftsmen Limited. All Rights Reserved.
 */
package com.softwarecraftsmen.decompressors;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;

public class GzipDecompressor implements Decompressor
{
	private GzipDecompressor()
	{}

	@NotNull
	public static Decompressor GZip = new GzipDecompressor();

	private static final int OneKilobyte = 1024;
	private static final int BufferSize = 8 * OneKilobyte;

	public void decompress(final @NotNull InputStream inputStream, final @NotNull OutputStream outputStream) throws IOException
	{
		final GZIPInputStream gzipInputStream = new GZIPInputStream(inputStream, BufferSize);
		final byte[] buffer = new byte[BufferSize];
		int bytesRead;
		while ((bytesRead = gzipInputStream.read(buffer)) != -1)
		{
			outputStream.write(buffer, 0, bytesRead);
		}
	}
}