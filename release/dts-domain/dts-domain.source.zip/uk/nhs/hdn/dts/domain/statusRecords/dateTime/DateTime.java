package uk.nhs.hdn.dts.domain.statusRecords.dateTime;

import uk.nhs.hdn.common.serialisers.ValueSerialisable;
import uk.nhs.hdn.common.unknown.IsUnknown;

public interface DateTime extends ValueSerialisable, IsUnknown
{
}
