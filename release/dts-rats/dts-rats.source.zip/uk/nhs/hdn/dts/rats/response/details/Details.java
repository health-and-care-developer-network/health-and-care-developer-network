package uk.nhs.hdn.dts.rats.response.details;

import uk.nhs.hdn.common.serialisers.MapSerialisable;
import uk.nhs.hdn.common.unknown.IsUnknown;

public interface Details extends IsUnknown, MapSerialisable
{
}
